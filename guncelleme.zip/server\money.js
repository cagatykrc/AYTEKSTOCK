export function parseMoneyKurus(input, allowEmpty = false) {
  const text = String(input ?? '');
  if (!text.trim()) return allowEmpty ? 0 : null;
  let raw = text.trim().replace(/\s/g, '').replace(/₺/g, '').replace(/tl/ig, '');
  let whole = raw;
  let frac = '';
  if (raw.includes(',')) {
    const parts = raw.split(',');
    if (parts.length !== 2) return null;
    whole = parts[0].replace(/\./g, '');
    frac = parts[1];
  } else if (/^\d+\.\d{1,2}$/.test(raw)) {
    const dot = raw.split('.');
    whole = dot[0];
    frac = dot[1];
  } else {
    whole = raw.replace(/\./g, '');
  }
  if (!/^\d+$/.test(whole)) return null;
  if (frac !== '' && !/^\d{1,2}$/.test(frac)) return null;
  const kurus = Number(whole) * 100 + Number((`${frac}00`).slice(0, 2));
  if (!Number.isSafeInteger(kurus) || kurus < 0 || kurus > 100_000_000) return null;
  return kurus;
}

export function allocateExtra(pool, qty, stock) {
  const extra = Math.trunc(Number(pool) || 0);
  const take = Math.trunc(Number(qty) || 0);
  const have = Math.trunc(Number(stock) || 0);
  if (extra <= 0 || take <= 0 || have <= 0) return 0;
  if (take >= have) return extra;
  return Math.floor((extra * take) / have);
}

export function splitUnit(total, qty) {
  const amount = Math.trunc(Number(total) || 0);
  const count = Math.trunc(Number(qty) || 0);
  if (count <= 0) return { unit: 0, adjust: amount };
  const unit = Math.floor(amount / count);
  return { unit, adjust: amount - unit * count };
}

export function shareExtra(lines, pools) {
  const given = new Map();
  const seen = new Map();
  const totals = new Map();
  for (const line of lines) {
    totals.set(line.productId, (totals.get(line.productId) || 0) + line.qty);
  }
  return lines.map((line) => {
    const pool = pools.get(line.productId) || 0;
    const totalQty = totals.get(line.productId) || line.qty;
    const before = seen.get(line.productId) || 0;
    const already = given.get(line.productId) || 0;
    const share = before + line.qty >= totalQty
      ? pool - already
      : Math.floor((pool * line.qty) / totalQty);
    given.set(line.productId, already + share);
    seen.set(line.productId, before + line.qty);
    return share;
  });
}

export function weightedCost(oldStock, oldCost, addQty, addCost) {
  const have = Math.trunc(Number(oldStock) || 0);
  const cost = Math.trunc(Number(oldCost) || 0);
  const qty = Math.trunc(Number(addQty) || 0);
  const next = Math.trunc(Number(addCost) || 0);
  if (qty <= 0) return cost;
  if (have <= 0) return next;
  const total = have * cost + qty * next;
  const denom = have + qty;
  return Math.floor((total * 2 + denom) / (denom * 2));
}

export function lineRevenue(qty, unitSale, priceAdjust = 0) {
  return qty * unitSale + priceAdjust;
}

export function lineProfit(qty, unitSale, unitCost, priceAdjust = 0, extraAdjust = 0) {
  return qty * (unitSale - unitCost) + priceAdjust - extraAdjust;
}

export function grossExpr(alias = 'l') {
  return `${alias}.qty * ${alias}.unit_sale_price + COALESCE(${alias}.price_adjust, 0)`;
}

export function profitExpr(alias = 'l') {
  return `${alias}.qty * (${alias}.unit_sale_price - ${alias}.unit_cost_price) + COALESCE(${alias}.price_adjust, 0) - COALESCE(${alias}.extra_adjust, 0)`;
}
