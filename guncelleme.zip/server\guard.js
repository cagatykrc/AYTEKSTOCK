import { randomBytes, timingSafeEqual } from 'node:crypto';

const localHosts = new Set(['127.0.0.1', 'localhost']);
let minted = '';
let desk = '';

export function sessionToken() {
  if (!minted) minted = randomBytes(32).toString('base64url');
  return minted;
}

export function deskToken() {
  if (!desk) desk = randomBytes(32).toString('base64url');
  return desk;
}

export function injectSession(html, token) {
  const safe = typeof token === 'string' && /^[A-Za-z0-9_-]+$/.test(token) ? token : '';
  const meta = `<meta name="ay-session" content="${safe}" />`;
  if (html.includes('name="ay-session"')) {
    return html.replace(/<meta name="ay-session" content="[^"]*"\s*\/?>/, meta);
  }
  if (!html.includes('<head>')) return html;
  return html.replace('<head>', `<head>${meta}`);
}

function localError(status, message) {
  const error = new Error(message);
  error.status = status;
  return error;
}

function oneHeader(headers, name) {
  if (!headers || typeof headers !== 'object') return '';
  const value = headers[name];
  if (Array.isArray(value)) return null;
  if (typeof value !== 'string') return '';
  return value;
}

export function isLocalHost(value) {
  if (typeof value !== 'string') return false;
  const trimmed = value.trim().toLowerCase();
  if (!trimmed || /[\s@\[\]]/.test(trimmed)) return false;
  const colon = trimmed.lastIndexOf(':');
  const name = colon === -1 ? trimmed : trimmed.slice(0, colon);
  const port = colon === -1 ? '' : trimmed.slice(colon + 1);
  if (port && !/^\d{1,5}$/.test(port)) return false;
  if (port && Number(port) > 65535) return false;
  return localHosts.has(name);
}

export function isLocalOrigin(value) {
  if (typeof value !== 'string' || !value.trim()) return false;
  let url;
  try {
    url = new URL(value);
  } catch {
    return false;
  }
  if (url.username || url.password || url.search || url.hash) return false;
  if (url.protocol !== 'http:') return false;
  if (url.pathname !== '/') return false;
  return localHosts.has(url.hostname);
}

function unsafeMethod(method) {
  const verb = String(method || 'GET').toUpperCase();
  return verb !== 'GET' && verb !== 'HEAD';
}

export function assertLocalRequest(req) {
  const headers = req?.headers;
  const host = oneHeader(headers, 'host');
  if (host == null || !isLocalHost(host)) throw localError(403, 'Yerel olmayan istek');
  const origin = oneHeader(headers, 'origin');
  if (origin == null || (origin && !isLocalOrigin(origin))) throw localError(403, 'Yerel olmayan istek');
  if (unsafeMethod(req?.method) && !origin) throw localError(403, 'Yerel olmayan istek');
}

function presentedToken(header) {
  if (typeof header !== 'string') return '';
  const match = /^Bearer ([A-Za-z0-9_-]+)$/.exec(header.trim());
  return match ? match[1] : '';
}

function sameToken(expectedText, presented) {
  const expected = Buffer.from(expectedText);
  const actual = Buffer.from(String(presented || ''));
  if (actual.length !== expected.length) return false;
  return timingSafeEqual(actual, expected);
}

export function tokenMatches(presented) {
  return sameToken(sessionToken(), presented);
}

export function tokenMatchesDesk(presented) {
  return sameToken(deskToken(), presented);
}

export function assertSession(req) {
  const header = oneHeader(req?.headers, 'authorization');
  if (header == null || !tokenMatches(presentedToken(header))) {
    throw localError(401, 'Oturum gerekli');
  }
}

export function assertDesk(req) {
  const header = oneHeader(req?.headers, 'authorization');
  if (header == null || !tokenMatchesDesk(presentedToken(header))) {
    throw localError(401, 'Oturum gerekli');
  }
}

function assertShopToken(req) {
  const header = oneHeader(req?.headers, 'authorization');
  const presented = presentedToken(header);
  if (header == null || !(tokenMatches(presented) || tokenMatchesDesk(presented))) {
    throw localError(401, 'Oturum gerekli');
  }
}

function isKioskApi(method, pathname) {
  const verb = String(method || 'GET').toUpperCase();
  return (verb === 'GET' && pathname === '/api/session')
    || (verb === 'POST' && pathname === '/api/vitrin/unlock')
    || (verb === 'POST' && pathname === '/api/settings/pin');
}

export function isPublicApi(method, pathname) {
  if (String(method || 'GET').toUpperCase() !== 'GET') return false;
  return pathname === '/api/health' || pathname === '/api/vitrin';
}

export function guardRequest(req, pathname, options = {}) {
  assertLocalRequest(req);
  if (!String(pathname || '').startsWith('/api')) return;
  if (isPublicApi(req?.method, pathname)) return;
  const pinSet = Boolean(options.pinSet);
  if (!pinSet) {
    assertShopToken(req);
    return;
  }
  if (isKioskApi(req?.method, pathname)) {
    assertSession(req);
    return;
  }
  assertDesk(req);
}
