export function brandName(value) {
  return String(value ?? '').trim().replace(/\s+/g, ' ').toLocaleUpperCase('tr-TR');
}

export function titleName(value) {
  const text = String(value ?? '').trim().replace(/\s+/g, ' ');
  if (!text) return '';
  return text.split(' ').map(titleToken).join(' ');
}

function titleToken(token) {
  return token.split(/([-/'’])/).map((part) => {
    if (!part || part === '-' || part === '/' || part === "'" || part === '’') return part;
    if (/\d/.test(part)) return part;
    const letters = [...part].filter((char) => /\p{L}/u.test(char));
    if (letters.length === 0) return part;
    const upper = letters.some((char) => char !== char.toLocaleLowerCase('tr-TR'));
    const lower = letters.some((char) => char !== char.toLocaleUpperCase('tr-TR'));
    if (upper && lower) return part;
    let capped = false;
    return [...part].map((char) => {
      if (!/\p{L}/u.test(char)) return char;
      if (!capped) {
        capped = true;
        return char.toLocaleUpperCase('tr-TR');
      }
      return char.toLocaleLowerCase('tr-TR');
    }).join('');
  }).join('');
}

export function formatPhone(input) {
  const trimmed = String(input ?? '').trim();
  if (trimmed === '+') return '+';
  const plus = trimmed.startsWith('+');
  let digits = trimmed.replace(/\D/g, '');
  if (!digits) return plus ? '+' : '';
  if (plus && (digits === '9' || digits === '90')) return `+${digits}`;
  let intl = plus;
  if (digits.startsWith('90') && (plus || digits.length > 11)) {
    digits = digits.slice(2);
    intl = true;
  }
  if (!digits) return intl ? '+90' : '';
  const body = digits.startsWith('0') ? chunk(digits, [4, 3, 2, 2]) : chunk(digits, [3, 3, 2, 2]);
  return intl ? `+90 ${body}` : body;
}

function chunk(digits, sizes) {
  const parts = [];
  let index = 0;
  for (const size of sizes) {
    if (index >= digits.length) break;
    parts.push(digits.slice(index, index + size));
    index += size;
  }
  if (index < digits.length) parts.push(digits.slice(index));
  return parts.join(' ');
}

export function maskMoneyInput(raw) {
  let text = String(raw ?? '').replace(/₺/g, '').replace(/tl/ig, '').replace(/\s/g, '');
  if (!text) return '';
  if (/^\d+\.\d{1,2}$/.test(text)) {
    const [whole, frac] = text.split('.');
    return `${groupDigits(whole)},${frac}`;
  }
  let frac = null;
  const comma = text.indexOf(',');
  if (comma >= 0) {
    frac = text.slice(comma + 1).replace(/\D/g, '').slice(0, 2);
    text = text.slice(0, comma);
  }
  const whole = groupDigits(text.replace(/\D/g, ''));
  if (frac == null) return whole;
  return `${whole || '0'},${frac}`;
}

function groupDigits(digits) {
  const trimmed = digits.replace(/^0+(?=\d)/, '');
  if (!trimmed) return '';
  return trimmed.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

export function digitCaret(formatted, digitsBefore) {
  if (digitsBefore <= 0) return formatted.match(/^\D*/)?.[0].length ?? 0;
  let seen = 0;
  for (let index = 0; index < formatted.length; index += 1) {
    if (/\d/.test(formatted[index])) {
      seen += 1;
      if (seen === digitsBefore) return index + 1;
    }
  }
  return formatted.length;
}
