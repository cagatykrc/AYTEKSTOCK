import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { backupDatabase, backupDir, checkPin, dataDir, db, getSetting, hashPin, importDatabase, localStamp, record, setSetting } from './db.js';
import { connectDrive, disconnectDrive, driveBackup, driveConfig, driveImport, saveDriveClient, saveDriveConfig } from './google.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const distDir = path.join(root, 'client', 'dist');
const versionPath = path.join(root, 'version.txt');
const updatePath = path.join(root, 'guncelleme.json');
const port = Number(process.env.PORT) || 4173;

function httpError(status, error) {
  const err = new Error(error);
  err.status = status;
  return err;
}

function send(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(body);
}

function readRaw(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(httpError(413, 'Yedek dosyası çok büyük'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > 1_000_000) {
        reject(httpError(413, 'İstek çok büyük'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw.trim()) {
        resolve({});
        return;
      }
      try {
        const data = JSON.parse(raw);
        if (!data || typeof data !== 'object' || Array.isArray(data)) {
          reject(httpError(400, 'Geçersiz istek'));
          return;
        }
        resolve(data);
      } catch {
        reject(httpError(400, 'Geçersiz istek'));
      }
    });
    req.on('error', reject);
  });
}

function withTx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (error) {
    try {
      db.exec('ROLLBACK');
    } catch {
      /* bağlantı zaten geri alındı */
    }
    throw error;
  }
}

function cleanText(value, label, max, required = false) {
  if (typeof value !== 'string') throw httpError(400, `${label} metin olmalı`);
  const text = value.trim();
  if (required && text.length === 0) throw httpError(400, `${label} gerekli`);
  if (text.length > max) throw httpError(400, `${label} en fazla ${max} karakter`);
  return text;
}

function cleanMoney(value, label) {
  if (!Number.isInteger(value) || value < 0 || value > 100_000_000) {
    throw httpError(400, `${label} geçersiz`);
  }
  return value;
}

function cleanDate(value, label) {
  const text = cleanText(value ?? '', label, 10);
  if (!text) return '';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) throw httpError(400, `${label} geçersiz`);
  const [year, month, day] = text.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
    throw httpError(400, `${label} geçersiz`);
  }
  return text;
}

function cleanUsed(body, current) {
  const used = 'used' in body ? body.used : Number(current?.used) === 1;
  if (typeof used !== 'boolean') throw httpError(400, 'Durum geçersiz');
  if (!used) return { used: 0, warrantyUntil: '', included: '' };
  const warrantyUntil = 'warrantyUntil' in body
    ? cleanDate(body.warrantyUntil, 'Garanti bitiş')
    : (current?.warranty_until || '');
  const included = 'included' in body
    ? cleanText(body.included ?? '', 'Birlikte gelenler', 200)
    : (current?.included || '');
  return { used: 1, warrantyUntil, included };
}

function cleanQty(value, label, allowZero = false) {
  const min = allowZero ? 0 : 1;
  if (!Number.isInteger(value) || value < min || value > 1_000_000) {
    throw httpError(400, `${label} geçersiz`);
  }
  return value;
}

function parseId(value) {
  if (!/^\d+$/.test(value)) throw httpError(400, 'Geçersiz kayıt');
  return Number(value);
}

function mapProduct(row) {
  return {
    id: Number(row.id),
    name: row.name,
    code: row.code,
    category: row.category,
    brand: row.brand || '',
    used: Number(row.used) === 1,
    warrantyUntil: row.warranty_until || '',
    included: row.included || '',
    costPrice: Number(row.cost_price),
    extraCost: Number(row.extra_cost || 0),
    salePrice: Number(row.sale_price),
    stock: Number(row.stock),
    lowStock: Number(row.low_stock),
    note: row.note,
    active: Number(row.active) === 1,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function mapMovement(row) {
  return {
    id: Number(row.id),
    type: row.type,
    qty: Number(row.qty),
    note: row.note,
    saleId: row.sale_id == null ? null : Number(row.sale_id),
    createdAt: row.created_at,
  };
}

function lineLabel(name, qty) {
  return Number(qty) > 1 ? `${name} ×${qty}` : name;
}

function mapLine(row) {
  return {
    id: Number(row.id),
    productId: Number(row.product_id),
    productName: row.product_name,
    qty: Number(row.qty),
    unitSalePrice: Number(row.unit_sale_price),
    unitCostPrice: Number(row.unit_cost_price),
    unitExtraCost: Number(row.unit_extra_cost || 0),
  };
}

function rowById(id) {
  const row = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  if (!row) throw httpError(404, 'Ürün bulunamadı');
  return row;
}

function listJournal() {
  return {
    entries: db.prepare(`
      SELECT id, kind, title, detail, ref, created_at
      FROM journal
      ORDER BY created_at DESC, id DESC
      LIMIT 200
    `).all().map((row) => ({
      id: Number(row.id),
      kind: row.kind,
      title: row.title,
      detail: row.detail,
      ref: row.ref || '',
      createdAt: row.created_at,
    })),
  };
}

function movementsFor(productId) {
  return db.prepare(`
    SELECT id, type, qty, note, sale_id, created_at
    FROM stock_movements
    WHERE product_id = ?
    ORDER BY id DESC
    LIMIT 50
  `).all(productId).map(mapMovement);
}

function expensesFor(productId) {
  return db.prepare(`
    SELECT id, amount, note, created_at
    FROM expenses
    WHERE product_id = ?
    ORDER BY id DESC
  `).all(productId).map((row) => ({
    id: Number(row.id),
    amount: Number(row.amount),
    note: row.note,
    createdAt: row.created_at,
  }));
}

function productDetail(id) {
  return { product: mapProduct(rowById(id)), movements: movementsFor(id), expenses: expensesFor(id) };
}

function addExpense(id, body) {
  const amount = cleanMoney(body.amount, 'Ek masraf');
  if (amount < 1) throw httpError(400, 'Ek masraf sıfırdan büyük olmalı');
  const note = cleanText(body.note ?? '', 'Not', 200);
  const now = localStamp();
  withTx(() => {
    const product = rowById(id);
    db.prepare('INSERT INTO expenses (product_id, amount, note, created_at) VALUES (?, ?, ?, ?)').run(id, amount, note, now);
    db.prepare('UPDATE products SET extra_cost = extra_cost + ?, updated_at = ? WHERE id = ?').run(amount, now, id);
    record('masraf', 'Ek masraf', `${product.name} · ${moneyLabel(amount)}${note ? ` · ${note}` : ''}`, `/stok/${id}`, now);
  });
  return productDetail(id);
}

function removeExpense(productId, expenseId) {
  const now = localStamp();
  withTx(() => {
    const row = db.prepare('SELECT amount FROM expenses WHERE id = ? AND product_id = ?').get(expenseId, productId);
    if (!row) throw httpError(404, 'Masraf bulunamadı');
    const product = rowById(productId);
    db.prepare('DELETE FROM expenses WHERE id = ?').run(expenseId);
    db.prepare('UPDATE products SET extra_cost = MAX(extra_cost - ?, 0), updated_at = ? WHERE id = ?').run(Number(row.amount), now, productId);
    record('masraf', 'Ek masraf silindi', `${product.name} · ${moneyLabel(row.amount)}`, `/stok/${productId}`, now);
  });
  return productDetail(productId);
}

function fold(value) {
  return String(value || '').toLocaleLowerCase('tr-TR').replaceAll('ı', 'i');
}

function listProducts(ctx) {
  const dusuk = ctx.url.searchParams.get('dusuk') === '1';
  const pasif = ctx.url.searchParams.get('pasif') === '1';
  const tumu = ctx.url.searchParams.get('tumu') === '1';
  const q = fold(ctx.url.searchParams.get('q') || '').trim();
  const limitParam = ctx.url.searchParams.get('limit');
  let rows = db.prepare('SELECT * FROM products').all();
  rows = rows.filter((row) => {
    if (pasif) return Number(row.active) !== 1;
    if (dusuk) return Number(row.active) === 1 && Number(row.stock) <= Number(row.low_stock);
    if (!tumu && Number(row.active) !== 1) return false;
    return true;
  });
  if (q) {
    const words = q.split(/\s+/).filter(Boolean);
    rows = rows.filter((row) => {
      const hay = fold(`${row.name} ${row.brand || ''} ${row.code} ${row.category} ${row.note} ${row.included || ''} ${Number(row.used) === 1 ? '2.El ikinci el' : ''}`);
      return words.every((word) => hay.includes(word));
    });
  }
  rows.sort((a, b) => Number(b.active) - Number(a.active) || String(a.name).localeCompare(String(b.name), 'tr'));
  if (limitParam) {
    const limit = Number(limitParam);
    if (!Number.isInteger(limit) || limit < 1 || limit > 50) throw httpError(400, 'Limit geçersiz');
    rows = rows.slice(0, limit);
  }
  return { products: rows.map(mapProduct) };
}

function categories() {
  return db.prepare(`SELECT DISTINCT category AS category FROM products WHERE category <> ''`).all()
    .map((row) => row.category)
    .sort((a, b) => a.localeCompare(b, 'tr'));
}

function createProduct(ctx) {
  const body = ctx.body;
  const name = cleanText(body.name, 'Ürün adı', 120, true);
  const code = cleanText(body.code ?? '', 'Kod', 40);
  const category = cleanText(body.category ?? '', 'Kategori', 40);
  const brand = cleanText(body.brand ?? '', 'Marka', 60);
  const second = cleanUsed(body);
  const note = cleanText(body.note ?? '', 'Not', 2000);
  const costPrice = cleanMoney(body.costPrice, 'Alış fiyatı');
  const salePrice = cleanMoney(body.salePrice, 'Satış fiyatı');
  const stock = cleanQty(body.stock ?? 0, 'Stok', true);
  const lowStock = cleanQty(body.lowStock ?? 1, 'Düşük stok eşiği', true);
  const now = localStamp();
  const id = withTx(() => {
    const info = db.prepare(`
      INSERT INTO products
        (name, code, category, brand, used, warranty_until, included, cost_price, sale_price, stock, low_stock, note, active, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    `).run(name, code, category, brand, second.used, second.warrantyUntil, second.included, costPrice, salePrice, stock, lowStock, note, now, now);
    const newId = Number(info.lastInsertRowid);
    if (stock > 0) {
      db.prepare(`
        INSERT INTO stock_movements (product_id, type, qty, note, sale_id, created_at)
        VALUES (?, 'giris', ?, 'İlk kayıt', NULL, ?)
      `).run(newId, stock, now);
    }
    record('urun', 'Ürün eklendi', name, `/stok/${newId}`, now);
    if (stock > 0) record('stok', 'Stok eklendi', `${name} · ${stock} adet`, `/stok/${newId}`, now);
    return newId;
  });
  return { product: mapProduct(rowById(id)) };
}

function updateProduct(id, body) {
  if ('stock' in body) throw httpError(400, 'Stok, stok hareketiyle güncellenir');
  const current = rowById(id);
  const name = 'name' in body ? cleanText(body.name, 'Ürün adı', 120, true) : current.name;
  const code = 'code' in body ? cleanText(body.code, 'Kod', 40) : current.code;
  const category = 'category' in body ? cleanText(body.category, 'Kategori', 40) : current.category;
  const brand = 'brand' in body ? cleanText(body.brand, 'Marka', 60) : (current.brand || '');
  const second = cleanUsed(body, current);
  const note = 'note' in body ? cleanText(body.note, 'Not', 2000) : current.note;
  const costPrice = 'costPrice' in body ? cleanMoney(body.costPrice, 'Alış fiyatı') : Number(current.cost_price);
  const salePrice = 'salePrice' in body ? cleanMoney(body.salePrice, 'Satış fiyatı') : Number(current.sale_price);
  const lowStock = 'lowStock' in body ? cleanQty(body.lowStock, 'Düşük stok eşiği', true) : Number(current.low_stock);
  let active = Number(current.active);
  if ('active' in body) {
    if (typeof body.active !== 'boolean') throw httpError(400, 'Durum geçersiz');
    active = body.active ? 1 : 0;
  }
  const now = localStamp();
  const changes = [];
  if (name !== current.name) changes.push('ad');
  if (brand !== (current.brand || '')) changes.push('marka');
  if (Number(second.used) !== Number(current.used || 0)) changes.push(Number(second.used) === 1 ? '2.El' : 'sıfır');
  if (costPrice !== Number(current.cost_price)) changes.push('alış fiyatı');
  if (salePrice !== Number(current.sale_price)) changes.push('satış fiyatı');
  if (lowStock !== Number(current.low_stock)) changes.push('düşük stok eşiği');
  if (note !== current.note) changes.push('not');
  const activeChanged = active !== Number(current.active);
  withTx(() => {
    db.prepare(`
      UPDATE products
      SET name = ?, code = ?, category = ?, brand = ?, used = ?, warranty_until = ?, included = ?, cost_price = ?, sale_price = ?, low_stock = ?, note = ?, active = ?, updated_at = ?
      WHERE id = ?
    `).run(name, code, category, brand, second.used, second.warrantyUntil, second.included, costPrice, salePrice, lowStock, note, active, now, id);
    if (activeChanged) record(active ? 'aktif' : 'pasif', active ? 'Satışa açıldı' : 'Pasife alındı', name, `/stok/${id}`, now);
    if (changes.length > 0) record('urun', 'Ürün güncellendi', `${name} · ${changes.join(', ')}`, `/stok/${id}`, now);
  });
  return { product: mapProduct(rowById(id)) };
}

function deleteProduct(id) {
  const product = rowById(id);
  withTx(() => {
    db.prepare('DELETE FROM expenses WHERE product_id = ?').run(id);
    db.prepare('DELETE FROM stock_movements WHERE product_id = ?').run(id);
    db.prepare('DELETE FROM products WHERE id = ?').run(id);
    record('sil', 'Ürün silindi', product.name);
  });
  return { ok: true };
}

function moneyLabel(kurus) {
  return (Number(kurus) / 100).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function adjustStock(id, body) {
  const note = cleanText(body.note ?? '', 'Not', 500);
  const now = localStamp();
  if (body.type !== 'giris' && body.type !== 'sayim') throw httpError(400, 'Hareket tipi geçersiz');
  withTx(() => {
    const product = rowById(id);
    if (body.type === 'giris') {
      const qty = cleanQty(body.qty, 'Giriş adedi');
      const costPrice = body.costPrice == null ? Number(product.cost_price) : cleanMoney(body.costPrice, 'Alış fiyatı');
      const changes = [];
      if (costPrice !== Number(product.cost_price)) changes.push(`alış ${moneyLabel(product.cost_price)} → ${moneyLabel(costPrice)}`);
      const movementNote = [note, changes.join(', ')].filter(Boolean).join(' · ');
      db.prepare('UPDATE products SET stock = stock + ?, cost_price = ?, updated_at = ? WHERE id = ?')
        .run(qty, costPrice, now, id);
      db.prepare(`
        INSERT INTO stock_movements (product_id, type, qty, note, sale_id, created_at)
        VALUES (?, 'giris', ?, ?, NULL, ?)
      `).run(id, qty, movementNote, now);
      record('stok', 'Stok eklendi', `${product.name} · ${qty} adet${costPrice !== Number(product.cost_price) ? ` · alış ${moneyLabel(costPrice)}` : ''}`, `/stok/${id}`, now);
      return;
    }
    const counted = cleanQty(body.qty, 'Sayım adedi', true);
    const delta = counted - Number(product.stock);
    if (delta === 0) throw httpError(400, 'Stok zaten bu adette');
    db.prepare('UPDATE products SET stock = ?, updated_at = ? WHERE id = ?').run(counted, now, id);
    db.prepare(`
      INSERT INTO stock_movements (product_id, type, qty, note, sale_id, created_at)
      VALUES (?, 'sayim', ?, ?, NULL, ?)
    `).run(id, delta, note, now);
    record('sayim', 'Sayım', `${product.name} · ${delta > 0 ? '+' : '−'}${Math.abs(delta)} adet`, `/stok/${id}`, now);
  });
  return productDetail(id);
}

function saleTotals(discount, lines) {
  const gross = lines.reduce((sum, line) => sum + line.qty * line.unitSalePrice, 0);
  const grossProfit = lines.reduce((sum, line) => sum + line.qty * (line.unitSalePrice - line.unitCostPrice), 0);
  return {
    gross,
    total: gross - discount,
    profit: grossProfit - discount,
    units: lines.reduce((sum, line) => sum + line.qty, 0),
  };
}

function mapSaleSummary(row) {
  const discount = Number(row.discount);
  const gross = Number(row.gross);
  return {
    id: Number(row.id),
    createdAt: row.created_at,
    paymentType: row.payment_type,
    discount,
    note: row.note,
    seller: row.seller || '',
    cancelledAt: row.cancelled_at,
    gross,
    total: gross - discount,
    profit: Number(row.gross_profit) - discount,
    units: Number(row.units),
    items: row.items || '',
  };
}

function getSale(id) {
  const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(id);
  if (!sale) throw httpError(404, 'Satış bulunamadı');
  const lines = db.prepare(`
    SELECT id, product_id, product_name, qty, unit_sale_price, unit_cost_price
    FROM sale_lines WHERE sale_id = ? ORDER BY id
  `).all(id).map(mapLine);
  const discount = Number(sale.discount);
  return {
    sale: {
      id: Number(sale.id),
      createdAt: sale.created_at,
      paymentType: sale.payment_type,
      discount,
      note: sale.note,
      seller: sale.seller || '',
      cancelledAt: sale.cancelled_at,
      ...saleTotals(discount, lines),
      items: lines.map((line) => lineLabel(line.productName, line.qty)).join(' · '),
      lines,
    },
  };
}

function shopName() {
  const stored = getSetting('shop_name');
  return stored && stored.trim() ? stored.trim() : 'Ay Teknoloji';
}

function appSettings() {
  return {
    shopName: shopName(),
    sellers: listSellers().sellers,
    dataDirectory: dataDir,
    backupDirectory: backupDir,
  };
}

function saveAppSettings(ctx) {
  const name = cleanText(typeof ctx.body.shopName === 'string' ? ctx.body.shopName : '', 'Dükkan adı', 40, true);
  const incoming = Array.isArray(ctx.body.sellers) ? ctx.body.sellers : [];
  const sellers = [0, 1, 2].map((index) => cleanText(typeof incoming[index] === 'string' ? incoming[index] : '', 'Satıcı', 40));
  const previousName = shopName();
  const previousSellers = listSellers().sellers.join('\n');
  setSetting('shop_name', name);
  setSetting('sellers', JSON.stringify(sellers));
  const notes = [];
  if (name !== previousName) notes.push('Dükkan adı');
  if (sellers.join('\n') !== previousSellers) notes.push('Satıcılar');
  if (notes.length > 0) record('ayar', 'Ayar', notes.join(' · '));
  return appSettings();
}

function openFolder(ctx) {
  const which = ctx.url.searchParams.get('which');
  const target = which === 'backup' ? backupDir : dataDir;
  fs.mkdirSync(target, { recursive: true });
  const child = spawn('explorer.exe', [target], { detached: true, stdio: 'ignore' });
  child.unref();
  return { ok: true };
}

const guideUrls = {
  drive: 'https://console.cloud.google.com/apis/library/drive.googleapis.com',
  client: 'https://console.cloud.google.com/auth/clients',
};

function openGuide(ctx) {
  const url = guideUrls[ctx.url.searchParams.get('which')];
  if (!url) throw httpError(400, 'Adres yok');
  const child = spawn('rundll32.exe', ['url.dll,FileProtocolHandler', url], {
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
  });
  child.unref();
  return { ok: true };
}

function listSellers() {
  const raw = getSetting('sellers');
  let stored = [];
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) stored = parsed;
    } catch {
      stored = [];
    }
  }
  return { sellers: [0, 1, 2].map((index) => (typeof stored[index] === 'string' ? stored[index] : '')) };
}

function saveSellers(ctx) {
  const incoming = Array.isArray(ctx.body.sellers) ? ctx.body.sellers : [];
  const sellers = [0, 1, 2].map((index) => cleanText(typeof incoming[index] === 'string' ? incoming[index] : '', 'Satıcı', 40));
  setSetting('sellers', JSON.stringify(sellers));
  return { sellers };
}

function listSales(ctx) {
  const where = [];
  const args = [];
  const from = ctx.url.searchParams.get('from');
  const to = ctx.url.searchParams.get('to');
  const payment = ctx.url.searchParams.get('payment');
  const seller = (ctx.url.searchParams.get('seller') || '').trim();
  const q = fold(ctx.url.searchParams.get('q') || '').trim();
  const iptal = ctx.url.searchParams.get('iptal') === '1';
  if (from) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(from)) throw httpError(400, 'Başlangıç tarihi geçersiz');
    where.push('s.created_at >= ?');
    args.push(`${from} 00:00:00`);
  }
  if (to) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(to)) throw httpError(400, 'Bitiş tarihi geçersiz');
    where.push('s.created_at <= ?');
    args.push(`${to} 23:59:59`);
  }
  if (payment) {
    if (payment !== 'nakit' && payment !== 'kart') throw httpError(400, 'Ödeme tipi geçersiz');
    where.push('s.payment_type = ?');
    args.push(payment);
  }
  if (seller) {
    if (seller.length > 40) throw httpError(400, 'Satıcı geçersiz');
    where.push('s.seller = ?');
    args.push(seller);
  }
  where.push(iptal ? 's.cancelled_at IS NOT NULL' : 's.cancelled_at IS NULL');
  const sql = `
    SELECT s.id, s.created_at, s.payment_type, s.discount, s.note, s.seller, s.cancelled_at,
      COALESCE(SUM(l.qty * l.unit_sale_price), 0) AS gross,
      COALESCE(SUM(l.qty * (l.unit_sale_price - l.unit_cost_price)), 0) AS gross_profit,
      COALESCE(SUM(l.qty), 0) AS units,
      (
        SELECT GROUP_CONCAT(label, ' · ')
        FROM (
          SELECT CASE WHEN qty > 1 THEN product_name || ' ×' || qty ELSE product_name END AS label
          FROM sale_lines
          WHERE sale_id = s.id
          ORDER BY id
        )
      ) AS items
    FROM sales s
    LEFT JOIN sale_lines l ON l.sale_id = s.id
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    GROUP BY s.id
    ORDER BY s.created_at DESC, s.id DESC
    ${q ? '' : 'LIMIT 200'}
  `;
  let rows = db.prepare(sql).all(...args);
  if (q) {
    const words = q.split(/\s+/).filter(Boolean);
    rows = rows.filter((row) => {
      const hay = fold(`${row.items || ''} ${row.seller || ''} ${row.note || ''} ${row.payment_type || ''}`);
      return words.every((word) => hay.includes(word));
    }).slice(0, 200);
  }
  return { sales: rows.map(mapSaleSummary) };
}

function normalizeLines(lines) {
  if (!Array.isArray(lines) || lines.length === 0) throw httpError(400, 'Sepete ürün ekle');
  if (lines.length > 100) throw httpError(400, 'Sepet çok uzun');
  return lines.map((line, index) => {
    if (!line || typeof line !== 'object') throw httpError(400, 'Satır geçersiz');
    if (!Number.isInteger(line.productId) || line.productId < 1) throw httpError(400, 'Ürün geçersiz');
    return {
      productId: line.productId,
      qty: cleanQty(line.qty, `${index + 1}. satır adedi`),
      unitSalePrice: cleanMoney(line.unitSalePrice, `${index + 1}. satır fiyatı`),
    };
  });
}

function createSale(ctx) {
  const body = ctx.body;
  const lines = normalizeLines(body.lines);
  const discount = cleanMoney(body.discount ?? 0, 'İndirim');
  const note = cleanText(body.note ?? '', 'Not', 2000);
  const seller = cleanText(body.seller ?? '', 'Satan', 40);
  if (body.paymentType !== 'nakit' && body.paymentType !== 'kart') {
    throw httpError(400, 'Ödeme tipi nakit veya kart olmalı');
  }
  const now = localStamp();
  const id = withTx(() => {
    const products = new Map();
    const needed = new Map();
    for (const line of lines) {
      if (!products.has(line.productId)) products.set(line.productId, rowById(line.productId));
      needed.set(line.productId, (needed.get(line.productId) || 0) + line.qty);
    }
    const subtotal = lines.reduce((sum, line) => sum + line.qty * line.unitSalePrice, 0);
    if (discount > subtotal) throw httpError(400, 'İndirim ara toplamı aşamaz');
    for (const [productId, qty] of needed) {
      const product = products.get(productId);
      if (Number(product.active) !== 1) throw httpError(400, `Ürün satışa kapalı: ${product.name}`);
      if (qty > Number(product.stock)) {
        throw httpError(400, `Stok yetmiyor: ${product.name} (rafta ${product.stock})`);
      }
    }
    const info = db.prepare(`
      INSERT INTO sales (created_at, payment_type, discount, note, seller, cancelled_at)
      VALUES (?, ?, ?, ?, ?, NULL)
    `).run(now, body.paymentType, discount, note, seller);
    const saleId = Number(info.lastInsertRowid);
    const insertLine = db.prepare(`
      INSERT INTO sale_lines (sale_id, product_id, product_name, qty, unit_sale_price, unit_cost_price, unit_extra_cost)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    const insertMove = db.prepare(`
      INSERT INTO stock_movements (product_id, type, qty, note, sale_id, created_at)
      VALUES (?, 'satis', ?, ?, ?, ?)
    `);
    const updateStock = db.prepare('UPDATE products SET stock = stock - ?, updated_at = ? WHERE id = ?');
    for (const line of lines) {
      const product = products.get(line.productId);
      const extra = Number(product.extra_cost || 0);
      insertLine.run(saleId, line.productId, product.name, line.qty, line.unitSalePrice, Number(product.cost_price) + extra, extra);
      insertMove.run(line.productId, -line.qty, note || 'Satış', saleId, now);
      updateStock.run(line.qty, now, line.productId);
    }
    const items = lines.map((line) => lineLabel(products.get(line.productId).name, line.qty)).join(' · ');
    record('satis', 'Satıldı', `${items}${seller ? ` · ${seller}` : ''}`, `/satis/${saleId}`, now);
    return saleId;
  });
  return getSale(id);
}

function cancelSale(id) {
  const now = localStamp();
  withTx(() => {
    const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(id);
    if (!sale) throw httpError(404, 'Satış bulunamadı');
    if (sale.cancelled_at) throw httpError(400, 'Satış zaten iptal');
    const lines = db.prepare('SELECT product_id, qty FROM sale_lines WHERE sale_id = ?').all(id);
    const updateStock = db.prepare('UPDATE products SET stock = stock + ?, updated_at = ? WHERE id = ?');
    const insertMove = db.prepare(`
      INSERT INTO stock_movements (product_id, type, qty, note, sale_id, created_at)
      VALUES (?, 'iptal', ?, 'Satış iptali', ?, ?)
    `);
    for (const line of lines) {
      updateStock.run(Number(line.qty), now, Number(line.product_id));
      insertMove.run(Number(line.product_id), Number(line.qty), id, now);
    }
    const names = db.prepare('SELECT product_name, qty FROM sale_lines WHERE sale_id = ? ORDER BY id').all(id);
    record('iptal', 'Satış iptal', names.map((line) => lineLabel(line.product_name, line.qty)).join(' · '), `/satis/${id}`, now);
    db.prepare('UPDATE sales SET cancelled_at = ? WHERE id = ?').run(now, id);
  });
  return getSale(id);
}

function startOfDay(date) {
  const next = new Date(date);
  next.setHours(0, 0, 0, 0);
  return next;
}

function startOfWeek(date) {
  const next = startOfDay(date);
  next.setDate(next.getDate() - ((next.getDay() + 6) % 7));
  return next;
}

function startOfMonth(date) {
  const next = startOfDay(date);
  next.setDate(1);
  return next;
}

function shiftDays(date, count) {
  const next = new Date(date);
  next.setDate(next.getDate() + count);
  return next;
}

function inSpan(rows, start, end) {
  const from = localStamp(start);
  const to = localStamp(end);
  return rows.filter((row) => row.created_at >= from && row.created_at < to);
}

function summarizeSpan(rows, payoutRows, start, end) {
  const summary = summarize(inSpan(rows, start, end));
  const from = localStamp(start);
  const to = localStamp(end);
  const outflow = payoutRows
    .filter((row) => row.created_at >= from && row.created_at < to)
    .reduce((sum, row) => sum + Number(row.amount), 0);
  return { ...summary, outflow };
}

function dayRows(rows, payoutRows, start, end) {
  const days = [];
  for (let cursor = new Date(start); cursor < end; cursor = shiftDays(cursor, 1)) {
    const key = dayKey(cursor);
    const next = shiftDays(cursor, 1);
    days.push({ date: key, ...summarizeSpan(rows, payoutRows, cursor, next) });
  }
  return days;
}

function sellerRows(rows) {
  const map = new Map();
  for (const row of rows) {
    const name = String(row.seller || '').trim();
    if (!name) continue;
    const current = map.get(name) || { name, count: 0, revenue: 0, profit: 0, units: 0 };
    current.count += 1;
    current.revenue += Number(row.gross) - Number(row.discount);
    current.profit += Number(row.gross_profit) - Number(row.discount);
    current.units += Number(row.units);
    map.set(name, current);
  }
  return [...map.values()].sort((a, b) => b.revenue - a.revenue || a.name.localeCompare(b.name, 'tr'));
}

function dayKey(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function summarize(rows) {
  const acc = { revenue: 0, profit: 0, count: 0, discount: 0, cash: 0, card: 0, units: 0 };
  for (const row of rows) {
    const revenue = Number(row.gross) - Number(row.discount);
    const profit = Number(row.gross_profit) - Number(row.discount);
    acc.revenue += revenue;
    acc.profit += profit;
    acc.discount += Number(row.discount);
    acc.count += 1;
    acc.units += Number(row.units);
    if (row.payment_type === 'nakit') acc.cash += revenue;
    else acc.card += revenue;
  }
  return acc;
}

function stats() {
  const now = new Date();
  const today = startOfDay(now);
  const week = startOfWeek(now);
  const month = startOfMonth(now);
  const chartStart = shiftDays(today, -13);
  const yesterday = shiftDays(today, -1);
  const tomorrow = shiftDays(today, 1);
  const previousWeek = shiftDays(week, -7);
  const previousMonth = startOfMonth(shiftDays(month, -1));
  const since = previousMonth;
  const rows = db.prepare(`
    SELECT s.id, s.created_at, s.payment_type, s.discount, s.seller,
      COALESCE(SUM(l.qty * l.unit_sale_price), 0) AS gross,
      COALESCE(SUM(l.qty * (l.unit_sale_price - l.unit_cost_price)), 0) AS gross_profit,
      COALESCE(SUM(l.qty), 0) AS units
    FROM sales s
    LEFT JOIN sale_lines l ON l.sale_id = s.id
    WHERE s.cancelled_at IS NULL AND s.created_at >= ?
    GROUP BY s.id
  `).all(localStamp(since));

  const stock = db.prepare(`
    SELECT
      COALESCE(SUM(CASE WHEN active = 1 THEN 1 ELSE 0 END), 0) AS product_count,
      COALESCE(SUM(CASE WHEN active = 1 AND stock > 0 THEN stock ELSE 0 END), 0) AS unit_count,
      COALESCE(SUM(CASE WHEN active = 1 AND stock > 0 THEN stock * (cost_price + extra_cost) ELSE 0 END), 0) AS cost_value,
      COALESCE(SUM(CASE WHEN active = 1 AND stock > 0 THEN stock * sale_price ELSE 0 END), 0) AS shelf_value,
      COALESCE(SUM(CASE WHEN active = 1 AND stock <= low_stock THEN 1 ELSE 0 END), 0) AS low_count
    FROM products
  `).get();

  const lowStock = db.prepare(`
    SELECT id, name, stock, low_stock
    FROM products
    WHERE active = 1 AND stock <= low_stock
    ORDER BY stock ASC, name ASC
    LIMIT 6
  `).all().map((row) => ({
    id: Number(row.id),
    name: row.name,
    stock: Number(row.stock),
    lowStock: Number(row.low_stock),
  }));

  const topSellers = db.prepare(`
    SELECT p.id, p.name,
      COALESCE(SUM(l.qty), 0) AS qty,
      COALESCE(SUM(l.qty * l.unit_sale_price), 0) AS revenue,
      COALESCE(SUM(l.qty * (l.unit_sale_price - l.unit_cost_price)), 0) AS profit
    FROM sale_lines l
    JOIN sales s ON s.id = l.sale_id
    JOIN products p ON p.id = l.product_id
    WHERE s.cancelled_at IS NULL AND s.created_at >= ?
    GROUP BY p.id
    ORDER BY qty DESC, revenue DESC
    LIMIT 5
  `).all(localStamp(month)).map((row) => ({
    id: Number(row.id),
    name: row.name,
    qty: Number(row.qty),
    revenue: Number(row.revenue),
    profit: Number(row.profit),
  }));

  const sinceKey = (start) => localStamp(start);
  const payoutRows = db.prepare('SELECT created_at, amount FROM payouts WHERE created_at >= ?').all(localStamp(since));
  const outflowSince = (start) => payoutRows
    .filter((row) => row.created_at >= sinceKey(start))
    .reduce((sum, row) => sum + Number(row.amount), 0);
  const withOutflow = (start, saleRows) => ({ ...summarize(saleRows), outflow: outflowSince(start) });
  const days = dayRows(rows, payoutRows, chartStart, tomorrow).map((day) => ({
    date: day.date,
    revenue: day.revenue,
    profit: day.profit,
    count: day.count,
  }));
  const receipts = db.prepare(`
    SELECT s.id, s.created_at, s.seller, s.payment_type, s.discount,
      COALESCE(SUM(l.qty * l.unit_sale_price), 0) AS gross,
      COALESCE(SUM(l.qty * (l.unit_sale_price - l.unit_cost_price)), 0) AS gross_profit,
      COALESCE(GROUP_CONCAT(CASE WHEN p.name IS NULL THEN NULL ELSE p.name END, ' · '), '') AS items
    FROM sales s
    LEFT JOIN sale_lines l ON l.sale_id = s.id
    LEFT JOIN products p ON p.id = l.product_id
    WHERE s.cancelled_at IS NULL AND s.created_at >= ?
    GROUP BY s.id
    ORDER BY s.created_at DESC
  `).all(localStamp(today)).map((row) => ({
    id: Number(row.id),
    createdAt: row.created_at,
    seller: row.seller || '',
    paymentType: row.payment_type === 'kart' ? 'kart' : 'nakit',
    total: Number(row.gross) - Number(row.discount),
    profit: Number(row.gross_profit) - Number(row.discount),
    items: row.items || '',
  }));
  const todayRows = inSpan(rows, today, tomorrow);
  const weekRows = inSpan(rows, week, tomorrow);
  const monthRows = inSpan(rows, month, tomorrow);
  return {
    today: withOutflow(today, todayRows),
    week: withOutflow(week, weekRows),
    month: withOutflow(month, monthRows),
    previous: {
      today: summarizeSpan(rows, payoutRows, yesterday, today),
      week: summarizeSpan(rows, payoutRows, previousWeek, week),
      month: summarizeSpan(rows, payoutRows, previousMonth, month),
    },
    spanDays: {
      today: dayRows(rows, payoutRows, today, tomorrow),
      week: dayRows(rows, payoutRows, week, tomorrow),
      month: dayRows(rows, payoutRows, month, tomorrow),
    },
    sellers: {
      today: sellerRows(todayRows),
      week: sellerRows(weekRows),
      month: sellerRows(monthRows),
    },
    receipts,
    stock: {
      productCount: Number(stock.product_count),
      unitCount: Number(stock.unit_count),
      costValue: Number(stock.cost_value),
      shelfValue: Number(stock.shelf_value),
      lowCount: Number(stock.low_count),
    },
    lowStock,
    topSellers,
    days,
  };
}

function mapPayout(row) {
  return {
    id: Number(row.id),
    amount: Number(row.amount),
    note: row.note,
    createdAt: row.created_at,
  };
}

function listPayouts() {
  const today = localStamp(startOfDay(new Date()));
  const rows = db.prepare('SELECT id, amount, note, created_at FROM payouts ORDER BY id DESC LIMIT 200').all();
  const todaySum = db.prepare('SELECT COALESCE(SUM(amount), 0) AS total FROM payouts WHERE created_at >= ?').get(today);
  return { payouts: rows.map(mapPayout), today: Number(todaySum.total) };
}

function createPayout(ctx) {
  const note = cleanText(typeof ctx.body?.note === 'string' ? ctx.body.note : '', 'Açıklama', 160);
  const amount = cleanMoney(ctx.body?.amount, 'Tutar');
  if (amount <= 0) throw httpError(400, 'Tutarı yaz');
  const now = localStamp();
  const info = db.prepare('INSERT INTO payouts (amount, note, created_at) VALUES (?, ?, ?)').run(amount, note || 'Gider', now);
  record('gider', 'Gider eklendi', `${note || 'Gider'} · ${moneyLabel(amount)}`, '/gider', now);
  return { payout: mapPayout({ id: info.lastInsertRowid, amount, note: note || 'Gider', created_at: now }) };
}

function deletePayout(id) {
  const row = db.prepare('SELECT amount, note FROM payouts WHERE id = ?').get(id);
  if (!row) throw httpError(404, 'Gider yok');
  db.prepare('DELETE FROM payouts WHERE id = ?').run(id);
  record('gider', 'Gider silindi', `${row.note || 'Gider'} · ${moneyLabel(row.amount)}`, '/gider');
  return { ok: true };
}

function vitrinSearch(ctx) {
  const q = fold(ctx.url.searchParams.get('q') || '').trim();
  if (!q) return { items: [] };
  const rows = db.prepare(`
    SELECT name, code, sale_price
    FROM products
    WHERE active = 1 AND stock > 0
  `).all();
  const items = [];
  for (const row of rows) {
    const name = String(row.name);
    const code = String(row.code || '');
    if (fold(name).includes(q) || fold(code).includes(q)) {
      items.push({ name, salePrice: Number(row.sale_price) });
    }
  }
  items.sort((a, b) => a.name.localeCompare(b.name, 'tr'));
  return { items: items.slice(0, 30) };
}

function setPin(ctx) {
  if (getSetting('pin')) throw httpError(409, 'PIN zaten tanımlı');
  const pin = typeof ctx.body.pin === 'string' ? ctx.body.pin : '';
  if (!/^\d{4}$/.test(pin)) throw httpError(400, 'PIN dört haneli olmalı');
  setSetting('pin', hashPin(pin));
  record('ayar', 'Ayar', 'Kilit şifresi tanımlandı');
  return { pinSet: true };
}

function unlock(ctx) {
  const pin = typeof ctx.body.pin === 'string' ? ctx.body.pin : '';
  if (!/^\d{4}$/.test(pin) || !checkPin(pin)) throw httpError(401, 'PIN hatalı');
  return { ok: true };
}

function readVersion() {
  try {
    return fs.readFileSync(versionPath, 'utf8').trim();
  } catch {
    return '';
  }
}

function readUpdateRepo() {
  try {
    const parsed = JSON.parse(fs.readFileSync(updatePath, 'utf8'));
    const repo = typeof parsed.repo === 'string' ? parsed.repo.trim() : '';
    return /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo) ? repo : '';
  } catch {
    return '';
  }
}

function updateInfo() {
  return { version: readVersion(), repo: readUpdateRepo() };
}

function saveUpdateRepo(ctx) {
  const repo = typeof ctx.body.repo === 'string' ? ctx.body.repo.trim() : '';
  if (repo && !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo)) {
    throw httpError(400, 'Depo kullanici/depo biçiminde olmalı');
  }
  const previous = readUpdateRepo();
  fs.writeFileSync(updatePath, `${JSON.stringify({ repo }, null, 2)}\n`);
  if (repo !== previous) record('ayar', 'Ayar', repo ? 'Güncelleme deposu kaydedildi' : 'Güncelleme deposu kaldırıldı');
  return updateInfo();
}

const routes = [
  ['GET', '/api/health', () => ({ ok: true })],
  ['GET', '/api/session', () => ({ pinSet: Boolean(getSetting('pin')) })],
  ['POST', '/api/settings/pin', setPin],
  ['POST', '/api/vitrin/unlock', unlock],
  ['GET', '/api/vitrin', vitrinSearch],
  ['GET', '/api/settings/app', appSettings],
  ['POST', '/api/settings/app', saveAppSettings],
  ['POST', '/api/settings/open-folder', openFolder],
  ['POST', '/api/settings/open-guide', openGuide],
  ['POST', '/api/backup', () => {
    const made = backupDatabase();
    record('ayar', 'Yedek alındı', made.file);
    return made;
  }],
  ['GET', '/api/journal', listJournal],
  ['GET', '/api/drive', driveConfig],
  ['POST', '/api/drive', saveDriveConfig],
  ['POST', '/api/drive/client', saveDriveClient],
  ['POST', '/api/drive/connect', connectDrive],
  ['POST', '/api/drive/disconnect', disconnectDrive],
  ['POST', '/api/drive/backup', driveBackup],
  ['POST', '/api/drive/import', driveImport],
  ['GET', '/api/update', updateInfo],
  ['POST', '/api/update', saveUpdateRepo],
  ['GET', '/api/stats', stats],
  ['GET', '/api/categories', () => ({ categories: categories() })],
  ['GET', '/api/products', listProducts],
  ['POST', '/api/products', createProduct],
  ['GET', '/api/products/:id', (ctx) => productDetail(parseId(ctx.params.id))],
  ['PATCH', '/api/products/:id', (ctx) => updateProduct(parseId(ctx.params.id), ctx.body)],
  ['POST', '/api/products/:id/stock', (ctx) => adjustStock(parseId(ctx.params.id), ctx.body)],
  ['POST', '/api/products/:id/expenses', (ctx) => addExpense(parseId(ctx.params.id), ctx.body)],
  ['DELETE', '/api/products/:id/expenses/:expenseId', (ctx) => removeExpense(parseId(ctx.params.id), parseId(ctx.params.expenseId))],
  ['DELETE', '/api/products/:id', (ctx) => deleteProduct(parseId(ctx.params.id))],
  ['GET', '/api/sellers', listSellers],
  ['POST', '/api/sellers', saveSellers],
  ['GET', '/api/payouts', listPayouts],
  ['POST', '/api/payouts', createPayout],
  ['DELETE', '/api/payouts/:id', (ctx) => deletePayout(parseId(ctx.params.id))],
  ['GET', '/api/sales', listSales],
  ['POST', '/api/sales', createSale],
  ['GET', '/api/sales/:id', (ctx) => getSale(parseId(ctx.params.id))],
  ['POST', '/api/sales/:id/cancel', (ctx) => cancelSale(parseId(ctx.params.id))],
];

function matchRoute(method, pathname) {
  for (const [routeMethod, routePath, handler] of routes) {
    if (routeMethod !== method) continue;
    const names = [];
    const pattern = routePath.replace(/:([A-Za-z]+)/g, (_, name) => {
      names.push(name);
      return '([^/]+)';
    });
    const matched = pathname.match(new RegExp(`^${pattern}$`));
    if (!matched) continue;
    const params = {};
    names.forEach((name, index) => {
      params[name] = matched[index + 1];
    });
    return { handler, params };
  }
  return null;
}

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function isInside(parent, file) {
  const relative = path.relative(parent, file);
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative));
}

function serveStatic(res, pathname) {
  const distRoot = path.resolve(distDir);
  const requested = path.resolve(distRoot, `.${pathname}`);
  let filePath = requested;
  if (!isInside(distRoot, filePath)) {
    res.writeHead(400);
    res.end();
    return;
  }
  const missing = !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory();
  if (missing) {
    if (path.extname(pathname)) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Bulunamadı');
      return;
    }
    filePath = path.join(distRoot, 'index.html');
  }
  const ext = path.extname(filePath).toLowerCase();
  res.writeHead(200, {
    'Content-Type': mime[ext] || 'application/octet-stream',
    'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=31536000, immutable',
  });
  fs.createReadStream(filePath).pipe(res);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', 'http://127.0.0.1');
    let pathname = decodeURIComponent(url.pathname);
    if (pathname.length > 1 && pathname.endsWith('/')) pathname = pathname.slice(0, -1);
    if (req.method === 'POST' && pathname === '/api/backup/import') {
      const bytes = await readRaw(req, 40_000_000);
      const restored = importDatabase(bytes);
      record('ayar', 'Yedek geri yüklendi', '');
      send(res, 200, restored);
      return;
    }
    if (pathname.startsWith('/api')) {
      const match = matchRoute(req.method || 'GET', pathname);
      if (!match) {
        send(res, 404, { error: 'Bulunamadı' });
        return;
      }
      const body = req.method === 'GET' || req.method === 'HEAD' ? {} : await readBody(req);
      const result = await match.handler({ body, params: match.params, url });
      send(res, 200, result);
      return;
    }
    if (!fs.existsSync(path.join(distDir, 'index.html'))) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<p>Arayüz henüz derlenmedi.</p>');
      return;
    }
    serveStatic(res, pathname);
  } catch (error) {
    const status = error.status || 500;
    if (status >= 500) console.error(error);
    if (!res.headersSent) {
      send(res, status, { error: status >= 500 ? 'Beklenmeyen bir hata oluştu' : error.message });
    }
  }
});

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`http://127.0.0.1:${port} kullanımda. Açık olan uygulamayı kapatıp yeniden dene.`);
  } else {
    console.error(error);
  }
  process.exit(1);
});

server.listen(port, '127.0.0.1', () => {
  console.log(`Ay Teknoloji hazır: http://127.0.0.1:${port}`);
});
