import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { backupDatabase, backupDir, checkPin, dataDir, db, getSetting, hashPin, importDatabase, localStamp, markShopChanged, onShopChanged, record, rememberCustomer, setSetting } from './db.js';
import { guardRequest, injectSession, sessionToken } from './guard.js';
import { connectDrive, disconnectDrive, driveBackup, driveConfig, driveImport, saveDriveClient, saveDriveConfig } from './google.js';
import { allocateExtra, grossExpr, lineProfit, lineRevenue, profitExpr, shareExtra, splitUnit, weightedCost } from './money.js';
import { brandName, formatPhone, titleName } from '../shared/text.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const distDir = path.join(root, 'client', 'dist');
const versionPath = path.join(root, 'version.txt');
const updatePath = path.join(root, 'guncelleme.json');
const port = Number(process.env.PORT) || 4173;

function httpError(status, error) {
  const err = new Error(error);
  err.status = status;
  return err;
}

function frameHeaders() {
  return {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Content-Security-Policy': "frame-ancestors 'none'",
    'Referrer-Policy': 'no-referrer',
    'Cross-Origin-Resource-Policy': 'same-origin',
  };
}

function send(res, status, data) {
  const body = JSON.stringify(data);
  const headers = {
    ...frameHeaders(),
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  };
  if (status === 401) headers['WWW-Authenticate'] = 'Bearer';
  res.writeHead(status, headers);
  res.end(body);
}

function readRaw(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(httpError(413, 'Yedek dosyası çok büyük'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > 1_000_000) {
        reject(httpError(413, 'İstek çok büyük'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw.trim()) {
        resolve({});
        return;
      }
      try {
        const data = JSON.parse(raw);
        if (!data || typeof data !== 'object' || Array.isArray(data)) {
          reject(httpError(400, 'Geçersiz istek'));
          return;
        }
        resolve(data);
      } catch {
        reject(httpError(400, 'Geçersiz istek'));
      }
    });
    req.on('error', reject);
  });
}

function withTx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (error) {
    try {
      db.exec('ROLLBACK');
    } catch {
      /* bağlantı zaten geri alındı */
    }
    throw error;
  }
}

function cleanText(value, label, max, required = false) {
  if (typeof value !== 'string') throw httpError(400, `${label} metin olmalı`);
  const text = value.trim();
  if (required && text.length === 0) throw httpError(400, `${label} gerekli`);
  if (text.length > max) throw httpError(400, `${label} en fazla ${max} karakter`);
  return text;
}

function cleanName(value, label, max, required = false) {
  return titleName(cleanText(value, label, max, required));
}

function cleanBrand(value, label, max, required = false) {
  return brandName(cleanText(value, label, max, required));
}

function cleanMoney(value, label) {
  if (!Number.isInteger(value) || value < 0 || value > 100_000_000) {
    throw httpError(400, `${label} geçersiz`);
  }
  return value;
}

function cleanDate(value, label) {
  const text = cleanText(value ?? '', label, 10);
  if (!text) return '';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) throw httpError(400, `${label} geçersiz`);
  const [year, month, day] = text.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
    throw httpError(400, `${label} geçersiz`);
  }
  return text;
}

function cleanUsed(body, current) {
  const used = 'used' in body ? body.used : Number(current?.used) === 1;
  if (typeof used !== 'boolean') throw httpError(400, 'Durum geçersiz');
  if (!used) return { used: 0, warrantyUntil: '', included: '' };
  const warrantyUntil = 'warrantyUntil' in body
    ? cleanDate(body.warrantyUntil, 'Garanti bitiş')
    : (current?.warranty_until || '');
  const included = 'included' in body
    ? cleanText(body.included ?? '', 'Birlikte gelenler', 200)
    : (current?.included || '');
  return { used: 1, warrantyUntil, included };
}

function cleanQty(value, label, allowZero = false) {
  const min = allowZero ? 0 : 1;
  if (!Number.isInteger(value) || value < min || value > 1_000_000) {
    throw httpError(400, `${label} geçersiz`);
  }
  return value;
}

function parseId(value) {
  if (!/^\d+$/.test(value)) throw httpError(400, 'Geçersiz kayıt');
  return Number(value);
}

function mapProduct(row) {
  return {
    id: Number(row.id),
    name: row.name,
    code: row.code,
    category: row.category,
    brand: row.brand || '',
    used: Number(row.used) === 1,
    warrantyUntil: row.warranty_until || '',
    included: row.included || '',
    costPrice: Number(row.cost_price),
    extraCost: Number(row.extra_cost || 0),
    salePrice: Number(row.sale_price),
    stock: Number(row.stock),
    lowStock: Number(row.low_stock),
    note: row.note,
    active: Number(row.active) === 1,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function mapMovement(row) {
  return {
    id: Number(row.id),
    type: row.type,
    qty: Number(row.qty),
    unitCost: Number(row.unit_cost || 0),
    note: row.note,
    saleId: row.sale_id == null ? null : Number(row.sale_id),
    createdAt: row.created_at,
  };
}

function lineLabel(name, qty) {
  return Number(qty) > 1 ? `${name} ×${qty}` : name;
}

function mapLine(row) {
  return {
    id: Number(row.id),
    productId: Number(row.product_id),
    productName: row.product_name,
    qty: Number(row.qty),
    unitSalePrice: Number(row.unit_sale_price),
    unitCostPrice: Number(row.unit_cost_price),
    unitExtraCost: Number(row.unit_extra_cost || 0),
    priceAdjust: Number(row.price_adjust || 0),
    extraAdjust: Number(row.extra_adjust || 0),
  };
}

function rowById(id) {
  const row = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  if (!row) throw httpError(404, 'Ürün bulunamadı');
  return row;
}

const journalKinds = new Set(['urun', 'stok', 'sayim', 'satis', 'iptal', 'sil', 'pasif', 'aktif', 'masraf', 'gider', 'ayar', 'tamir']);
const listPage = 200;

function listOffset(ctx) {
  const raw = ctx.url.searchParams.get('offset') || '0';
  if (!/^\d+$/.test(raw)) throw httpError(400, 'Sayfa geçersiz');
  const offset = Number(raw);
  if (offset > 20000) throw httpError(400, 'Sayfa geçersiz');
  return offset;
}

function mapJournalEntry(row) {
  return {
    id: Number(row.id),
    kind: row.kind,
    title: row.title,
    detail: row.detail,
    ref: row.ref || '',
    createdAt: row.created_at,
  };
}

function listJournal(ctx) {
  const where = [];
  const args = [];
  const kind = ctx.url.searchParams.get('kind') || '';
  const from = ctx.url.searchParams.get('from');
  const to = ctx.url.searchParams.get('to');
  const q = fold(ctx.url.searchParams.get('q') || '').trim();
  const offset = listOffset(ctx);
  if (kind) {
    if (!journalKinds.has(kind)) throw httpError(400, 'Hareket türü geçersiz');
    where.push('kind = ?');
    args.push(kind);
  }
  if (from) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(from)) throw httpError(400, 'Başlangıç tarihi geçersiz');
    where.push('created_at >= ?');
    args.push(`${from} 00:00:00`);
  }
  if (to) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(to)) throw httpError(400, 'Bitiş tarihi geçersiz');
    where.push('created_at <= ?');
    args.push(`${to} 23:59:59`);
  }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const sql = `
    SELECT id, kind, title, detail, ref, created_at
    FROM journal
    ${whereSql}
    ORDER BY created_at DESC, id DESC
  `;
  if (q) {
    const words = q.split(/\s+/).filter(Boolean);
    const rows = db.prepare(sql).all(...args).filter((row) => {
      const hay = fold(`${row.title} ${row.detail}`);
      return words.every((word) => hay.includes(word));
    });
    return {
      entries: rows.slice(offset, offset + listPage).map(mapJournalEntry),
      more: rows.length > offset + listPage,
      count: rows.length,
    };
  }
  const count = db.prepare(`SELECT COUNT(*) AS n FROM journal ${whereSql}`).get(...args);
  const rows = db.prepare(`${sql} LIMIT ? OFFSET ?`).all(...args, listPage + 1, offset);
  return {
    entries: rows.slice(0, listPage).map(mapJournalEntry),
    more: rows.length > listPage,
    count: Number(count.n),
  };
}

function movementsFor(productId) {
  return db.prepare(`
    SELECT id, type, qty, unit_cost, note, sale_id, created_at
    FROM stock_movements
    WHERE product_id = ?
    ORDER BY id DESC
    LIMIT 50
  `).all(productId).map(mapMovement);
}

function expensesFor(productId) {
  return db.prepare(`
    SELECT id, amount, note, created_at
    FROM expenses
    WHERE product_id = ?
    ORDER BY id DESC
  `).all(productId).map((row) => ({
    id: Number(row.id),
    amount: Number(row.amount),
    note: row.note,
    createdAt: row.created_at,
  }));
}

function productDetail(id) {
  return { product: mapProduct(rowById(id)), movements: movementsFor(id), expenses: expensesFor(id) };
}

function addExpense(id, body) {
  const amount = cleanMoney(body.amount, 'Ek masraf');
  if (amount < 1) throw httpError(400, 'Ek masraf sıfırdan büyük olmalı');
  const note = cleanText(body.note ?? '', 'Not', 200);
  const now = localStamp();
  withTx(() => {
    const product = rowById(id);
    db.prepare('INSERT INTO expenses (product_id, amount, note, created_at) VALUES (?, ?, ?, ?)').run(id, amount, note, now);
    db.prepare('UPDATE products SET extra_cost = extra_cost + ?, updated_at = ? WHERE id = ?').run(amount, now, id);
    record('masraf', 'Ek masraf', `${product.name} · ${moneyLabel(amount)}${note ? ` · ${note}` : ''}`, `/stok/${id}`, now);
  });
  return productDetail(id);
}

function removeExpense(productId, expenseId) {
  const now = localStamp();
  withTx(() => {
    const row = db.prepare('SELECT amount FROM expenses WHERE id = ? AND product_id = ?').get(expenseId, productId);
    if (!row) throw httpError(404, 'Masraf bulunamadı');
    const product = rowById(productId);
    db.prepare('DELETE FROM expenses WHERE id = ?').run(expenseId);
    db.prepare('UPDATE products SET extra_cost = MAX(extra_cost - ?, 0), updated_at = ? WHERE id = ?').run(Number(row.amount), now, productId);
    record('masraf', 'Ek masraf silindi', `${product.name} · ${moneyLabel(row.amount)}`, `/stok/${productId}`, now);
  });
  return productDetail(productId);
}

function fold(value) {
  return String(value || '').toLocaleLowerCase('tr-TR').replaceAll('ı', 'i');
}

function listProducts(ctx) {
  const dusuk = ctx.url.searchParams.get('dusuk') === '1';
  const pasif = ctx.url.searchParams.get('pasif') === '1';
  const tumu = ctx.url.searchParams.get('tumu') === '1';
  const q = fold(ctx.url.searchParams.get('q') || '').trim();
  const limitParam = ctx.url.searchParams.get('limit');
  let rows = db.prepare('SELECT * FROM products').all();
  rows = rows.filter((row) => {
    if (pasif) return Number(row.active) !== 1;
    if (dusuk) return Number(row.active) === 1 && Number(row.stock) <= Number(row.low_stock);
    if (!tumu && Number(row.active) !== 1) return false;
    return true;
  });
  if (q) {
    const words = q.split(/\s+/).filter(Boolean);
    rows = rows.filter((row) => {
      const hay = fold(`${row.name} ${row.brand || ''} ${row.code} ${row.category} ${row.note} ${row.included || ''} ${Number(row.used) === 1 ? '2.El ikinci el' : ''}`);
      return words.every((word) => hay.includes(word));
    });
  }
  rows.sort((a, b) => Number(b.active) - Number(a.active) || String(a.name).localeCompare(String(b.name), 'tr'));
  if (limitParam) {
    const limit = Number(limitParam);
    if (!Number.isInteger(limit) || limit < 1 || limit > 50) throw httpError(400, 'Limit geçersiz');
    rows = rows.slice(0, limit);
  }
  return { products: rows.map(mapProduct) };
}

function categories() {
  return db.prepare(`SELECT DISTINCT category AS category FROM products WHERE category <> ''`).all()
    .map((row) => row.category)
    .sort((a, b) => a.localeCompare(b, 'tr'));
}

function createProduct(ctx) {
  const body = ctx.body;
  const name = cleanName(body.name, 'Ürün adı', 120, true);
  const code = cleanText(body.code ?? '', 'Kod', 40);
  const category = cleanText(body.category ?? '', 'Kategori', 40);
  const brand = cleanBrand(body.brand ?? '', 'Marka', 60);
  const second = cleanUsed(body);
  const note = cleanText(body.note ?? '', 'Not', 2000);
  const costPrice = cleanMoney(body.costPrice, 'Alış fiyatı');
  const salePrice = cleanMoney(body.salePrice, 'Satış fiyatı');
  const stock = cleanQty(body.stock ?? 0, 'Stok', true);
  const lowStock = cleanQty(body.lowStock ?? 1, 'Düşük stok eşiği', true);
  const now = localStamp();
  const id = withTx(() => {
    const info = db.prepare(`
      INSERT INTO products
        (name, code, category, brand, used, warranty_until, included, cost_price, sale_price, stock, low_stock, note, active, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    `).run(name, code, category, brand, second.used, second.warrantyUntil, second.included, costPrice, salePrice, stock, lowStock, note, now, now);
    const newId = Number(info.lastInsertRowid);
    if (stock > 0) {
      db.prepare(`
        INSERT INTO stock_movements (product_id, type, qty, unit_cost, note, sale_id, created_at)
        VALUES (?, 'giris', ?, ?, 'İlk kayıt', NULL, ?)
      `).run(newId, stock, costPrice, now);
    }
    record('urun', 'Ürün eklendi', name, `/stok/${newId}`, now);
    if (stock > 0) {
      record(
        'stok',
        'Stok eklendi',
        `${name} · ${stock} adet · alış ${moneyLabel(costPrice * stock)}`,
        `/stok/${newId}`,
        now,
      );
    }
    return newId;
  });
  return { product: mapProduct(rowById(id)) };
}

function updateProduct(id, body) {
  if ('stock' in body) throw httpError(400, 'Stok, stok hareketiyle güncellenir');
  const current = rowById(id);
  const name = 'name' in body ? cleanName(body.name, 'Ürün adı', 120, true) : current.name;
  const code = 'code' in body ? cleanText(body.code, 'Kod', 40) : current.code;
  const category = 'category' in body ? cleanText(body.category, 'Kategori', 40) : current.category;
  const brand = 'brand' in body ? cleanBrand(body.brand, 'Marka', 60) : (current.brand || '');
  const second = cleanUsed(body, current);
  const note = 'note' in body ? cleanText(body.note, 'Not', 2000) : current.note;
  const costPrice = 'costPrice' in body ? cleanMoney(body.costPrice, 'Alış fiyatı') : Number(current.cost_price);
  const salePrice = 'salePrice' in body ? cleanMoney(body.salePrice, 'Satış fiyatı') : Number(current.sale_price);
  const lowStock = 'lowStock' in body ? cleanQty(body.lowStock, 'Düşük stok eşiği', true) : Number(current.low_stock);
  let active = Number(current.active);
  if ('active' in body) {
    if (typeof body.active !== 'boolean') throw httpError(400, 'Durum geçersiz');
    active = body.active ? 1 : 0;
  }
  const now = localStamp();
  const changes = [];
  if (name !== current.name) changes.push('ad');
  if (brand !== (current.brand || '')) changes.push('marka');
  if (Number(second.used) !== Number(current.used || 0)) changes.push(Number(second.used) === 1 ? '2.El' : 'sıfır');
  if (costPrice !== Number(current.cost_price)) changes.push('alış fiyatı');
  if (salePrice !== Number(current.sale_price)) changes.push('satış fiyatı');
  if (lowStock !== Number(current.low_stock)) changes.push('düşük stok eşiği');
  if (note !== current.note) changes.push('not');
  const activeChanged = active !== Number(current.active);
  withTx(() => {
    db.prepare(`
      UPDATE products
      SET name = ?, code = ?, category = ?, brand = ?, used = ?, warranty_until = ?, included = ?, cost_price = ?, sale_price = ?, low_stock = ?, note = ?, active = ?, updated_at = ?
      WHERE id = ?
    `).run(name, code, category, brand, second.used, second.warrantyUntil, second.included, costPrice, salePrice, lowStock, note, active, now, id);
    if (activeChanged) record(active ? 'aktif' : 'pasif', active ? 'Satışa açıldı' : 'Pasife alındı', name, `/stok/${id}`, now);
    if (changes.length > 0) record('urun', 'Ürün güncellendi', `${name} · ${changes.join(', ')}`, `/stok/${id}`, now);
  });
  return { product: mapProduct(rowById(id)) };
}

function deleteProduct(id) {
  const product = rowById(id);
  const sales = db.prepare('SELECT COUNT(*) AS n FROM sale_lines WHERE product_id = ?').get(id);
  const parts = db.prepare('SELECT COUNT(*) AS n FROM repair_parts WHERE product_id = ?').get(id);
  if (Number(sales.n) + Number(parts.n) > 0) {
    throw httpError(409, 'Bu ürünün satışı veya tamir kaydı var. Silinmez; pasife alınır.');
  }
  withTx(() => {
    db.prepare('DELETE FROM expenses WHERE product_id = ?').run(id);
    db.prepare('DELETE FROM stock_movements WHERE product_id = ?').run(id);
    db.prepare('DELETE FROM products WHERE id = ?').run(id);
    record('sil', 'Ürün silindi', product.name);
  });
  return { ok: true };
}

function moneyLabel(kurus) {
  return (Number(kurus) / 100).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function adjustStock(id, body) {
  const note = cleanText(body.note ?? '', 'Not', 500);
  const now = localStamp();
  if (body.type !== 'giris' && body.type !== 'sayim') throw httpError(400, 'Hareket tipi geçersiz');
  withTx(() => {
    const product = rowById(id);
    if (body.type === 'giris') {
      const qty = cleanQty(body.qty, 'Giriş adedi');
      const entered = body.costPrice == null ? Number(product.cost_price) : cleanMoney(body.costPrice, 'Alış fiyatı');
      const costPrice = body.costPrice == null
        ? Number(product.cost_price)
        : weightedCost(Number(product.stock), Number(product.cost_price), qty, entered);
      const spend = qty * entered;
      const changes = [];
      if (costPrice !== Number(product.cost_price)) changes.push(`alış ${moneyLabel(product.cost_price)} → ${moneyLabel(costPrice)}`);
      const movementNote = [note, changes.join(', ')].filter(Boolean).join(' · ');
      db.prepare('UPDATE products SET stock = stock + ?, cost_price = ?, updated_at = ? WHERE id = ?')
        .run(qty, costPrice, now, id);
      db.prepare(`
        INSERT INTO stock_movements (product_id, type, qty, unit_cost, note, sale_id, created_at)
        VALUES (?, 'giris', ?, ?, ?, NULL, ?)
      `).run(id, qty, entered, movementNote, now);
      record('stok', 'Stok eklendi', `${product.name} · ${qty} adet · alış ${moneyLabel(spend)}`, `/stok/${id}`, now);
      return;
    }
    const counted = cleanQty(body.qty, 'Sayım adedi', true);
    const delta = counted - Number(product.stock);
    if (delta === 0) throw httpError(400, 'Stok zaten bu adette');
    db.prepare('UPDATE products SET stock = ?, updated_at = ? WHERE id = ?').run(counted, now, id);
    db.prepare(`
      INSERT INTO stock_movements (product_id, type, qty, note, sale_id, created_at)
      VALUES (?, 'sayim', ?, ?, NULL, ?)
    `).run(id, delta, note, now);
    record('sayim', 'Sayım', `${product.name} · ${delta > 0 ? '+' : '−'}${Math.abs(delta)} adet`, `/stok/${id}`, now);
  });
  return productDetail(id);
}

function saleTotals(discount, lines) {
  const gross = lines.reduce((sum, line) => sum + lineRevenue(line.qty, line.unitSalePrice, line.priceAdjust || 0), 0);
  const grossProfit = lines.reduce((sum, line) => sum + lineProfit(line.qty, line.unitSalePrice, line.unitCostPrice, line.priceAdjust || 0, line.extraAdjust || 0), 0);
  return {
    gross,
    total: gross - discount,
    profit: grossProfit - discount,
    units: lines.reduce((sum, line) => sum + line.qty, 0),
  };
}

function mapSaleSummary(row) {
  const discount = Number(row.discount);
  const gross = Number(row.gross);
  const total = gross - discount;
  const paid = Number(row.paid || 0);
  return {
    id: Number(row.id),
    createdAt: row.created_at,
    paymentType: row.payment_type,
    discount,
    note: row.note,
    seller: row.seller || '',
    customer: row.customer || '',
    phone: row.phone || '',
    paid,
    remaining: row.payment_type === 'veresiye' ? Math.max(0, total - paid) : 0,
    cancelledAt: row.cancelled_at,
    gross,
    total,
    profit: profitAfterPos(Number(row.gross_profit) - discount, gross - discount, row.payment_type),
    units: Number(row.units),
    items: row.items || '',
  };
}

function getSale(id) {
  const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(id);
  if (!sale) throw httpError(404, 'Satış bulunamadı');
  const lines = db.prepare(`
    SELECT id, product_id, product_name, qty, unit_sale_price, unit_cost_price, unit_extra_cost, price_adjust, extra_adjust
    FROM sale_lines WHERE sale_id = ? ORDER BY id
  `).all(id).map(mapLine);
  const discount = Number(sale.discount);
  const totals = saleTotals(discount, lines);
  const posCut = sale.payment_type === 'kart' ? posCutOf(totals.total) : 0;
  const payments = db.prepare(`
    SELECT id, amount, payment_type, note, created_at
    FROM credit_payments WHERE sale_id = ? ORDER BY id
  `).all(id).map((row) => ({
    id: Number(row.id),
    amount: Number(row.amount),
    paymentType: row.payment_type,
    note: row.note || '',
    createdAt: row.created_at,
  }));
  const paid = payments.reduce((sum, row) => sum + row.amount, 0);
  return {
    sale: {
      id: Number(sale.id),
      createdAt: sale.created_at,
      paymentType: sale.payment_type,
      discount,
      note: sale.note,
      seller: sale.seller || '',
      customer: sale.customer || '',
      phone: sale.phone || '',
      paid,
      remaining: sale.payment_type === 'veresiye' ? Math.max(0, totals.total - paid) : 0,
      payments,
      cancelledAt: sale.cancelled_at,
      ...totals,
      profit: totals.profit - posCut,
      posCut,
      items: lines.map((line) => lineLabel(line.productName, line.qty)).join(' · '),
      lines,
    },
  };
}

function shopName() {
  const stored = getSetting('shop_name');
  return stored && stored.trim() ? stored.trim() : 'Ay Teknoloji';
}

function posRate() {
  const raw = getSetting('pos_rate');
  if (raw == null || raw === '') return 0;
  const rate = Number(raw);
  if (!Number.isInteger(rate) || rate < 0 || rate > 100) return 0;
  return rate;
}

function posCutOf(amount) {
  return Math.round(Number(amount) * posRate() / 100);
}

function profitAfterPos(profit, total, paymentType) {
  if (paymentType !== 'kart') return profit;
  return profit - posCutOf(total);
}

function appSettings() {
  return {
    shopName: shopName(),
    sellers: listSellers().sellers,
    posRate: posRate(),
    dataDirectory: dataDir,
    backupDirectory: backupDir,
  };
}

function saveAppSettings(ctx) {
  const name = cleanText(typeof ctx.body.shopName === 'string' ? ctx.body.shopName : '', 'Dükkan adı', 40, true);
  const incoming = Array.isArray(ctx.body.sellers) ? ctx.body.sellers : [];
  const sellers = [0, 1, 2].map((index) => cleanText(typeof incoming[index] === 'string' ? incoming[index] : '', 'Satıcı', 40));
  const rate = Number(ctx.body.posRate);
  if (!Number.isInteger(rate) || rate < 0 || rate > 100) throw httpError(400, 'POS kesintisi 0 ile 100 arasında olmalı');
  const previousName = shopName();
  const previousSellers = listSellers().sellers.join('\n');
  const previousRate = posRate();
  setSetting('shop_name', name);
  setSetting('sellers', JSON.stringify(sellers));
  setSetting('pos_rate', String(rate));
  const notes = [];
  if (name !== previousName) notes.push('Dükkan adı');
  if (sellers.join('\n') !== previousSellers) notes.push('Satıcılar');
  if (rate !== previousRate) notes.push(`POS kesintisi %${rate}`);
  if (notes.length > 0) record('ayar', 'Ayar', notes.join(' · '));
  return appSettings();
}

function openFolder(ctx) {
  const which = ctx.url.searchParams.get('which');
  const target = which === 'backup' ? backupDir : dataDir;
  fs.mkdirSync(target, { recursive: true });
  const child = spawn('explorer.exe', [target], { detached: true, stdio: 'ignore' });
  child.unref();
  return { ok: true };
}

const guideUrls = {
  drive: 'https://console.cloud.google.com/apis/library/drive.googleapis.com',
  client: 'https://console.cloud.google.com/auth/clients',
};

function openGuide(ctx) {
  const url = guideUrls[ctx.url.searchParams.get('which')];
  if (!url) throw httpError(400, 'Adres yok');
  const child = spawn('rundll32.exe', ['url.dll,FileProtocolHandler', url], {
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
  });
  child.unref();
  return { ok: true };
}

function listSellers() {
  const raw = getSetting('sellers');
  let stored = [];
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) stored = parsed;
    } catch {
      stored = [];
    }
  }
  return { sellers: [0, 1, 2].map((index) => (typeof stored[index] === 'string' ? stored[index] : '')) };
}

function saveSellers(ctx) {
  const incoming = Array.isArray(ctx.body.sellers) ? ctx.body.sellers : [];
  const sellers = [0, 1, 2].map((index) => cleanText(typeof incoming[index] === 'string' ? incoming[index] : '', 'Satıcı', 40));
  setSetting('sellers', JSON.stringify(sellers));
  return { sellers };
}

function listSales(ctx) {
  const where = [];
  const args = [];
  const from = ctx.url.searchParams.get('from');
  const to = ctx.url.searchParams.get('to');
  const payment = ctx.url.searchParams.get('payment');
  const seller = (ctx.url.searchParams.get('seller') || '').trim();
  const q = fold(ctx.url.searchParams.get('q') || '').trim();
  const offset = listOffset(ctx);
  const iptal = ctx.url.searchParams.get('iptal') === '1';
  if (from) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(from)) throw httpError(400, 'Başlangıç tarihi geçersiz');
    where.push('s.created_at >= ?');
    args.push(`${from} 00:00:00`);
  }
  if (to) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(to)) throw httpError(400, 'Bitiş tarihi geçersiz');
    where.push('s.created_at <= ?');
    args.push(`${to} 23:59:59`);
  }
  if (payment) {
    if (payment !== 'nakit' && payment !== 'kart' && payment !== 'veresiye') throw httpError(400, 'Ödeme tipi geçersiz');
    where.push('s.payment_type = ?');
    args.push(payment);
  }
  if (seller) {
    if (seller.length > 40) throw httpError(400, 'Satıcı geçersiz');
    where.push('s.seller = ?');
    args.push(seller);
  }
  where.push(iptal ? 's.cancelled_at IS NOT NULL' : 's.cancelled_at IS NULL');
  const sql = `
    SELECT s.id, s.created_at, s.payment_type, s.discount, s.note, s.seller, s.customer, s.phone, s.cancelled_at,
      COALESCE((SELECT SUM(amount) FROM credit_payments WHERE sale_id = s.id), 0) AS paid,
      COALESCE(SUM(${grossExpr()}), 0) AS gross,
      COALESCE(SUM(${profitExpr()}), 0) AS gross_profit,
      COALESCE(SUM(l.qty), 0) AS units,
      (
        SELECT GROUP_CONCAT(label, ' · ')
        FROM (
          SELECT CASE WHEN qty > 1 THEN product_name || ' ×' || qty ELSE product_name END AS label
          FROM sale_lines
          WHERE sale_id = s.id
          ORDER BY id
        )
      ) AS items
    FROM sales s
    LEFT JOIN sale_lines l ON l.sale_id = s.id
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    GROUP BY s.id
    ORDER BY s.created_at DESC, s.id DESC
  `;
  const repairs = matchingRepairs(ctx);
  const repairTotal = repairs.reduce((sum, row) => sum + row.fee, 0);
  if (q) {
    const words = q.split(/\s+/).filter(Boolean);
    const rows = db.prepare(sql).all(...args).filter((row) => {
      const hay = fold(`${row.items || ''} ${row.seller || ''} ${row.customer || ''} ${row.phone || ''} ${row.note || ''} ${row.payment_type || ''}`);
      return words.every((word) => hay.includes(word));
    });
    const total = rows.reduce((sum, row) => sum + Number(row.gross) - Number(row.discount), 0);
    return {
      sales: rows.slice(offset, offset + listPage).map(mapSaleSummary),
      repairs,
      repairTotal,
      more: rows.length > offset + listPage,
      count: rows.length,
      total,
    };
  }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const summary = db.prepare(`
    SELECT COUNT(*) AS n, COALESCE(SUM(total), 0) AS total FROM (
      SELECT COALESCE(SUM(${grossExpr()}), 0) - s.discount AS total
      FROM sales s
      LEFT JOIN sale_lines l ON l.sale_id = s.id
      ${whereSql}
      GROUP BY s.id
    )
  `).get(...args);
  const rows = db.prepare(`${sql} LIMIT ? OFFSET ?`).all(...args, listPage + 1, offset);
  return {
    sales: rows.slice(0, listPage).map(mapSaleSummary),
    repairs,
    repairTotal,
    more: rows.length > listPage,
    count: Number(summary.n),
    total: Number(summary.total),
  };
}

function matchingRepairs(ctx) {
  if (ctx.url.searchParams.get('iptal') === '1') return [];
  const from = ctx.url.searchParams.get('from');
  const to = ctx.url.searchParams.get('to');
  const payment = ctx.url.searchParams.get('payment');
  const seller = (ctx.url.searchParams.get('seller') || '').trim();
  const q = fold(ctx.url.searchParams.get('q') || '').trim();
  const where = ["status = 'teslim'", 'fee > 0'];
  const args = [];
  if (from) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(from)) throw httpError(400, 'Başlangıç tarihi geçersiz');
    where.push('delivered_at >= ?');
    args.push(`${from} 00:00:00`);
  }
  if (to) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(to)) throw httpError(400, 'Bitiş tarihi geçersiz');
    where.push('delivered_at <= ?');
    args.push(`${to} 23:59:59`);
  }
  if (payment === 'veresiye') {
    where.push("payment_type = 'veresiye'");
  } else if (payment) {
    if (payment !== 'nakit' && payment !== 'kart') throw httpError(400, 'Ödeme tipi geçersiz');
    where.push('payment_type = ?');
    args.push(payment);
  }
  if (seller) {
    if (seller.length > 40) throw httpError(400, 'Satıcı geçersiz');
    where.push('seller = ?');
    args.push(seller);
  }
  let rows = db.prepare(`
    SELECT id, delivered_at, fee, payment_type, seller, device, customer,
      COALESCE((SELECT SUM(amount) FROM credit_payments WHERE repair_id = repairs.id), 0) AS paid
    FROM repairs
    WHERE ${where.join(' AND ')}
    ORDER BY delivered_at DESC, id DESC
  `).all(...args);
  if (q) {
    const words = q.split(/\s+/).filter(Boolean);
    rows = rows.filter((row) => {
      const hay = fold(`tamir ${row.device || ''} ${row.customer || ''} ${row.seller || ''}`);
      return words.every((word) => hay.includes(word));
    });
  }
  return rows.map((row) => ({
    id: Number(row.id),
    deliveredAt: row.delivered_at,
    fee: Number(row.fee),
    paymentType: row.payment_type === 'kart' ? 'kart' : row.payment_type === 'veresiye' ? 'veresiye' : 'nakit',
    remaining: row.payment_type === 'veresiye' ? Math.max(0, Number(row.fee) - Number(row.paid || 0)) : 0,
    seller: row.seller || '',
    device: row.device || '',
    customer: row.customer || '',
  }));
}

function normalizeLines(lines) {
  if (!Array.isArray(lines) || lines.length === 0) throw httpError(400, 'Sepete ürün ekle');
  if (lines.length > 100) throw httpError(400, 'Sepet çok uzun');
  return lines.map((line, index) => {
    if (!line || typeof line !== 'object') throw httpError(400, 'Satır geçersiz');
    if (!Number.isInteger(line.productId) || line.productId < 1) throw httpError(400, 'Ürün geçersiz');
    const qty = cleanQty(line.qty, `${index + 1}. satır adedi`);
    const label = `${index + 1}. satır tutarı`;
    if (Number.isInteger(line.lineTotal)) {
      const split = splitUnit(cleanMoney(line.lineTotal, label), qty);
      return { productId: line.productId, qty, unitSalePrice: split.unit, priceAdjust: split.adjust };
    }
    return {
      productId: line.productId,
      qty,
      unitSalePrice: cleanMoney(line.unitSalePrice, label),
      priceAdjust: 0,
    };
  });
}

function createSale(ctx) {
  const body = ctx.body;
  const lines = normalizeLines(body.lines);
  const discount = cleanMoney(body.discount ?? 0, 'İndirim');
  const note = cleanText(body.note ?? '', 'Not', 2000);
  const seller = cleanText(body.seller ?? '', 'Satan', 40);
  if (body.paymentType !== 'nakit' && body.paymentType !== 'kart' && body.paymentType !== 'veresiye') {
    throw httpError(400, 'Ödeme tipi nakit, kart veya veresiye olmalı');
  }
  const customer = body.paymentType === 'veresiye' ? cleanName(body.customer ?? '', 'Müşteri', 80, true) : '';
  const phone = body.paymentType === 'veresiye' ? cleanPhone(body.phone ?? '') : '';
  const now = localStamp();
  const id = withTx(() => {
    const products = new Map();
    const needed = new Map();
    for (const line of lines) {
      if (!products.has(line.productId)) products.set(line.productId, rowById(line.productId));
      needed.set(line.productId, (needed.get(line.productId) || 0) + line.qty);
    }
    const subtotal = lines.reduce((sum, line) => sum + lineRevenue(line.qty, line.unitSalePrice, line.priceAdjust), 0);
    if (discount > subtotal) throw httpError(400, 'İndirim ara toplamı aşamaz');
    for (const [productId, qty] of needed) {
      const product = products.get(productId);
      if (Number(product.active) !== 1) throw httpError(400, `Ürün satışa kapalı: ${product.name}`);
      if (qty > Number(product.stock)) {
        throw httpError(400, `Stok yetmiyor: ${product.name} (rafta ${product.stock})`);
      }
    }
    const info = db.prepare(`
      INSERT INTO sales (created_at, payment_type, discount, note, seller, cancelled_at, customer, phone)
      VALUES (?, ?, ?, ?, ?, NULL, ?, ?)
    `).run(now, body.paymentType, discount, note, seller, customer, phone);
    if (customer) rememberCustomer(customer, phone, now);
    const saleId = Number(info.lastInsertRowid);
    const pools = new Map();
    for (const [productId, qty] of needed) {
      const product = products.get(productId);
      pools.set(productId, allocateExtra(Number(product.extra_cost || 0), qty, Number(product.stock)));
    }
    const shares = shareExtra(lines, pools);
    const insertLine = db.prepare(`
      INSERT INTO sale_lines (sale_id, product_id, product_name, qty, unit_sale_price, unit_cost_price, unit_extra_cost, price_adjust, extra_adjust, extra_taken)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertMove = db.prepare(`
      INSERT INTO stock_movements (product_id, type, qty, note, sale_id, created_at)
      VALUES (?, 'satis', ?, ?, ?, ?)
    `);
    const updateStock = db.prepare('UPDATE products SET stock = stock - ?, extra_cost = extra_cost - ?, updated_at = ? WHERE id = ?');
    lines.forEach((line, index) => {
      const product = products.get(line.productId);
      const lineExtra = shares[index];
      const extraSplit = splitUnit(lineExtra, line.qty);
      const unitCost = Number(product.cost_price) + extraSplit.unit;
      insertLine.run(saleId, line.productId, product.name, line.qty, line.unitSalePrice, unitCost, extraSplit.unit, line.priceAdjust, extraSplit.adjust, lineExtra);
      insertMove.run(line.productId, -line.qty, note || 'Satış', saleId, now);
      updateStock.run(line.qty, lineExtra, now, line.productId);
    });
    const items = lines.map((line) => lineLabel(products.get(line.productId).name, line.qty)).join(' · ');
    const who = body.paymentType === 'veresiye' ? customer : seller;
    record('satis', body.paymentType === 'veresiye' ? 'Veresiye satıldı' : 'Satıldı', `${items}${who ? ` · ${who}` : ''}`, `/satis/${saleId}`, now);
    return saleId;
  });
  return getSale(id);
}

function cancelSale(id) {
  const now = localStamp();
  withTx(() => {
    const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(id);
    if (!sale) throw httpError(404, 'Satış bulunamadı');
    if (sale.cancelled_at) throw httpError(400, 'Satış zaten iptal');
    const collected = db.prepare('SELECT COALESCE(SUM(amount), 0) AS paid FROM credit_payments WHERE sale_id = ?').get(id);
    if (Number(collected.paid) > 0) throw httpError(400, 'Tahsilatı olan borç iptal edilmez');
    const lines = db.prepare('SELECT product_id, qty, extra_taken FROM sale_lines WHERE sale_id = ?').all(id);
    const updateStock = db.prepare('UPDATE products SET stock = stock + ?, extra_cost = extra_cost + ?, updated_at = ? WHERE id = ?');
    const insertMove = db.prepare(`
      INSERT INTO stock_movements (product_id, type, qty, note, sale_id, created_at)
      VALUES (?, 'iptal', ?, 'Satış iptali', ?, ?)
    `);
    for (const line of lines) {
      const product = db.prepare('SELECT id FROM products WHERE id = ?').get(line.product_id);
      if (!product) continue;
      updateStock.run(Number(line.qty), Number(line.extra_taken || 0), now, Number(line.product_id));
      insertMove.run(Number(line.product_id), Number(line.qty), id, now);
    }
    const names = db.prepare('SELECT product_name, qty FROM sale_lines WHERE sale_id = ? ORDER BY id').all(id);
    record('iptal', 'Satış iptal', names.map((line) => lineLabel(line.product_name, line.qty)).join(' · '), `/satis/${id}`, now);
    db.prepare('UPDATE sales SET cancelled_at = ? WHERE id = ?').run(now, id);
  });
  return getSale(id);
}

function creditBalance(saleId) {
  const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(saleId);
  if (!sale) return null;
  const lines = db.prepare(`
    SELECT qty, unit_sale_price, unit_cost_price, price_adjust, extra_adjust
    FROM sale_lines WHERE sale_id = ?
  `).all(saleId).map((row) => ({
    qty: Number(row.qty),
    unitSalePrice: Number(row.unit_sale_price),
    unitCostPrice: Number(row.unit_cost_price),
    priceAdjust: Number(row.price_adjust || 0),
    extraAdjust: Number(row.extra_adjust || 0),
  }));
  const totals = saleTotals(Number(sale.discount), lines);
  const taken = db.prepare('SELECT COALESCE(SUM(amount), 0) AS paid, COALESCE(SUM(profit), 0) AS profit FROM credit_payments WHERE sale_id = ?').get(saleId);
  const paid = Number(taken.paid);
  return {
    sale,
    totals,
    paid,
    profitTaken: Number(taken.profit),
    remaining: totals.total - paid,
  };
}

function settleCredit(saleId, amount, paymentType, note, now) {
  const balance = creditBalance(saleId);
  if (!balance) throw httpError(404, 'Satış bulunamadı');
  const { sale, totals, remaining, profitTaken } = balance;
  if (sale.cancelled_at) throw httpError(400, 'İptal edilmiş satış');
  if (sale.payment_type !== 'veresiye') throw httpError(400, 'Bu satış veresiye değil');
  if (remaining < 1) throw httpError(400, 'Bu borç kapanmış');
  if (amount > remaining) throw httpError(400, 'Tahsilat kalan borcu aşamaz');
  const share = remaining === amount
    ? totals.profit - profitTaken
    : Math.round(totals.profit * amount / totals.total);
  db.prepare(`
    INSERT INTO credit_payments (sale_id, amount, payment_type, profit, note, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(saleId, amount, paymentType, share, note, now);
  return sale;
}

function repairBalance(repairId) {
  const repair = db.prepare('SELECT * FROM repairs WHERE id = ?').get(repairId);
  if (!repair) return null;
  const parts = db.prepare('SELECT COALESCE(SUM(cost), 0) AS cost FROM repair_parts WHERE repair_id = ? AND restored = 0').get(repairId);
  const fee = Number(repair.fee);
  const profit = fee - Number(parts.cost);
  const taken = db.prepare('SELECT COALESCE(SUM(amount), 0) AS paid, COALESCE(SUM(profit), 0) AS profit FROM credit_payments WHERE repair_id = ?').get(repairId);
  const paid = Number(taken.paid);
  return { repair, fee, profit, paid, profitTaken: Number(taken.profit), remaining: fee - paid };
}

function settleRepairCredit(repairId, amount, paymentType, note, now) {
  const balance = repairBalance(repairId);
  if (!balance) throw httpError(404, 'Tamir kaydı bulunamadı');
  const { repair, fee, profit, remaining, profitTaken } = balance;
  if (repair.status !== 'teslim') throw httpError(400, 'Tamir teslim edilmemiş');
  if (repair.payment_type !== 'veresiye') throw httpError(400, 'Bu tamir veresiye değil');
  if (remaining < 1) throw httpError(400, 'Bu borç kapanmış');
  if (amount > remaining) throw httpError(400, 'Tahsilat kalan borcu aşamaz');
  const share = remaining === amount ? profit - profitTaken : Math.round(profit * amount / fee);
  db.prepare(`
    INSERT INTO credit_payments (repair_id, amount, payment_type, profit, note, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(repairId, amount, paymentType, share, note, now);
  return repair;
}

function readPayment(body) {
  const amount = cleanMoney(body.amount, 'Tahsilat');
  if (amount < 1) throw httpError(400, 'Tahsilatı yaz');
  if (body.paymentType !== 'nakit' && body.paymentType !== 'kart') {
    throw httpError(400, 'Ödeme tipi nakit veya kart olmalı');
  }
  return { amount, paymentType: body.paymentType, note: cleanText(body.note ?? '', 'Not', 200) };
}

function payCredit(id, body) {
  const payment = readPayment(body);
  const now = localStamp();
  withTx(() => {
    const sale = settleCredit(id, payment.amount, payment.paymentType, payment.note, now);
    const who = sale.customer || 'Müşteri';
    record('tahsilat', 'Borç tahsil edildi', `${who} · ${moneyLabel(payment.amount)}`, `/satis/${id}`, now);
  });
  return getSale(id);
}

function payRepair(id, body) {
  const payment = readPayment(body);
  const now = localStamp();
  withTx(() => {
    const repair = settleRepairCredit(id, payment.amount, payment.paymentType, payment.note, now);
    const who = repair.customer || repair.device || 'Tamir';
    record('tahsilat', 'Borç tahsil edildi', `${who} · ${moneyLabel(payment.amount)}`, `/tamir/${id}`, now);
  });
  return getRepair(id);
}

function openCreditSlips(customerKey) {
  const sales = db.prepare(`
    SELECT id, customer, created_at AS at FROM sales
    WHERE payment_type = 'veresiye' AND cancelled_at IS NULL
  `).all().filter((row) => fold(row.customer).trim() === customerKey).map((row) => ({ kind: 'satis', id: Number(row.id), at: row.at }));
  const repairs = db.prepare(`
    SELECT id, customer, delivered_at AS at FROM repairs
    WHERE payment_type = 'veresiye' AND status = 'teslim'
  `).all().filter((row) => fold(row.customer).trim() === customerKey).map((row) => ({ kind: 'tamir', id: Number(row.id), at: row.at }));
  return [...sales, ...repairs].sort((a, b) => String(a.at).localeCompare(String(b.at)) || a.id - b.id);
}

function payCustomer(body) {
  const customer = cleanName(body.customer ?? '', 'Müşteri', 80, true);
  const payment = readPayment(body);
  const key = fold(customer).trim();
  const now = localStamp();
  withTx(() => {
    const slips = openCreditSlips(key);
    let left = payment.amount;
    for (const slip of slips) {
      if (left < 1) break;
      const balance = slip.kind === 'tamir' ? repairBalance(slip.id) : creditBalance(slip.id);
      if (!balance || balance.remaining < 1) continue;
      const take = Math.min(left, balance.remaining);
      if (slip.kind === 'tamir') settleRepairCredit(slip.id, take, payment.paymentType, payment.note, now);
      else settleCredit(slip.id, take, payment.paymentType, payment.note, now);
      left -= take;
    }
    const applied = payment.amount - left;
    if (applied < 1) throw httpError(400, 'Bu kişinin açık borcu yok');
    if (left > 0) throw httpError(400, 'Tahsilat kalan borcu aşamaz');
    record('tahsilat', 'Borç tahsil edildi', `${customer} · ${moneyLabel(applied)}`, '/borc', now);
  });
  return listDebts();
}

function listDebts() {
  const rows = db.prepare(`
    SELECT s.id, s.created_at, s.customer, s.phone, s.seller, s.discount,
      COALESCE(SUM(${grossExpr()}), 0) AS gross,
      COALESCE((SELECT SUM(amount) FROM credit_payments WHERE sale_id = s.id), 0) AS paid,
      (
        SELECT GROUP_CONCAT(label, ' · ')
        FROM (
          SELECT CASE WHEN qty > 1 THEN product_name || ' ×' || qty ELSE product_name END AS label
          FROM sale_lines
          WHERE sale_id = s.id
          ORDER BY id
        )
      ) AS items
    FROM sales s
    LEFT JOIN sale_lines l ON l.sale_id = s.id
    WHERE s.payment_type = 'veresiye' AND s.cancelled_at IS NULL
    GROUP BY s.id
    ORDER BY s.created_at ASC, s.id ASC
  `).all();
  const debts = rows.map((row) => {
    const total = Number(row.gross) - Number(row.discount);
    const paid = Number(row.paid);
    return {
      saleId: Number(row.id),
      createdAt: row.created_at,
      customer: row.customer || '',
      phone: row.phone || '',
      seller: row.seller || '',
      items: row.items || '',
      total,
      paid,
      remaining: Math.max(0, total - paid),
      repairId: 0,
      kind: 'satis',
    };
  }).filter((row) => row.remaining > 0);
  const jobs = db.prepare(`
    SELECT r.id, r.delivered_at, r.customer, r.phone, r.seller, r.device, r.fee,
      COALESCE((SELECT SUM(amount) FROM credit_payments WHERE repair_id = r.id), 0) AS paid
    FROM repairs r
    WHERE r.payment_type = 'veresiye' AND r.status = 'teslim' AND r.fee > 0
    ORDER BY r.delivered_at ASC, r.id ASC
  `).all().map((row) => {
    const total = Number(row.fee);
    const paid = Number(row.paid);
    return {
      saleId: 0,
      repairId: Number(row.id),
      kind: 'tamir',
      createdAt: row.delivered_at,
      customer: row.customer || '',
      phone: row.phone || '',
      seller: row.seller || '',
      items: `Tamir · ${row.device || ''}`.trim(),
      total,
      paid,
      remaining: Math.max(0, total - paid),
    };
  }).filter((row) => row.remaining > 0);
  debts.push(...jobs);
  debts.sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)) || (a.saleId || a.repairId) - (b.saleId || b.repairId));
  return {
    debts,
    total: debts.reduce((sum, row) => sum + row.remaining, 0),
  };
}

function listCustomers() {
  const owed = new Map();
  for (const debt of listDebts().debts) {
    const key = fold(debt.customer).trim();
    owed.set(key, (owed.get(key) || 0) + debt.remaining);
  }
  return {
    customers: db.prepare('SELECT name, name_key, phone FROM customers').all().map((row) => ({
      name: row.name,
      phone: row.phone || '',
      debt: owed.get(row.name_key) || 0,
    })).sort((a, b) => a.name.localeCompare(b.name, 'tr')),
  };
}

function startOfDay(date) {
  const next = new Date(date);
  next.setHours(0, 0, 0, 0);
  return next;
}

function startOfWeek(date) {
  const next = startOfDay(date);
  next.setDate(next.getDate() - ((next.getDay() + 6) % 7));
  return next;
}

function startOfMonth(date) {
  const next = startOfDay(date);
  next.setDate(1);
  return next;
}

function shiftDays(date, count) {
  const next = new Date(date);
  next.setDate(next.getDate() + count);
  return next;
}

function shiftMonths(date, count) {
  const next = startOfDay(date);
  const day = next.getDate();
  next.setDate(1);
  next.setMonth(next.getMonth() + count);
  const last = new Date(next.getFullYear(), next.getMonth() + 1, 0).getDate();
  next.setDate(Math.min(day, last));
  return next;
}

function parseDay(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return null;
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return null;
  return startOfDay(date);
}

function inSpan(rows, start, end) {
  const from = localStamp(start);
  const to = localStamp(end);
  return rows.filter((row) => row.created_at >= from && row.created_at < to);
}

function summarizeSpan(rows, payoutRows, repairRows, purchaseRows, start, end) {
  const summary = summarize(inSpan(rows, start, end));
  const from = localStamp(start);
  const to = localStamp(end);
  let repairs = 0;
  for (const row of repairRows) {
    if (row.created_at < from || row.created_at >= to) continue;
    if (row.payment_type === 'veresiye') continue;
    const fee = Number(row.fee);
    const parts = Number(row.parts_cost || 0);
    repairs += fee;
    summary.revenue += fee;
    summary.profit += fee - parts;
    if (row.payment_type === 'kart') summary.card += fee;
    else summary.cash += fee;
  }
  const outflow = payoutRows
    .filter((row) => row.created_at >= from && row.created_at < to)
    .reduce((sum, row) => sum + Number(row.amount), 0);
  let purchase = 0;
  let purchaseQty = 0;
  for (const row of purchaseRows) {
    if (row.created_at < from || row.created_at >= to) continue;
    purchase += Number(row.qty) * Number(row.unit_cost || 0);
    purchaseQty += Number(row.qty);
  }
  const cut = posCutOf(summary.card);
  summary.repairs = repairs;
  summary.outflow = outflow;
  summary.purchase = purchase;
  summary.purchaseQty = purchaseQty;
  summary.posCut = cut;
  summary.profit -= outflow + cut;
  summary.pocket = summary.cash + summary.card - cut - outflow;
  return summary;
}

function dayRows(rows, payoutRows, repairRows, purchaseRows, start, end) {
  const days = [];
  for (let cursor = new Date(start); cursor < end; cursor = shiftDays(cursor, 1)) {
    const key = dayKey(cursor);
    const next = shiftDays(cursor, 1);
    days.push({ date: key, ...summarizeSpan(rows, payoutRows, repairRows, purchaseRows, cursor, next) });
  }
  return days;
}

function sellerRows(rows, repairRows = []) {
  const map = new Map();
  const bucket = (name) => {
    const current = map.get(name) || { name, count: 0, revenue: 0, profit: 0, units: 0, repairs: 0, card: 0 };
    map.set(name, current);
    return current;
  };
  for (const row of rows) {
    const name = String(row.seller || '').trim();
    if (!name) continue;
    const current = bucket(name);
    const revenue = Number(row.gross) - Number(row.discount);
    if (row.payment_type === 'veresiye') {
      current.count += 1;
      current.units += Number(row.units);
      continue;
    }
    if (row.entry !== 'tahsilat') {
      current.count += 1;
      current.units += Number(row.units);
    }
    current.revenue += revenue;
    current.profit += Number(row.gross_profit) - Number(row.discount);
    if (row.payment_type === 'kart') current.card += revenue;
    if (row.repair) current.repairs += revenue;
  }
  for (const row of repairRows) {
    if (row.payment_type === 'veresiye') continue;
    const name = String(row.seller || '').trim();
    if (!name) continue;
    const fee = Number(row.fee);
    const parts = Number(row.parts_cost || 0);
    const current = bucket(name);
    current.revenue += fee;
    current.profit += fee - parts;
    current.repairs += fee;
    if (row.payment_type === 'kart') current.card += fee;
  }
  return [...map.values()]
    .map((seller) => ({
      name: seller.name,
      count: seller.count,
      revenue: seller.revenue,
      profit: seller.profit - posCutOf(seller.card),
      units: seller.units,
      repairs: seller.repairs,
    }))
    .sort((a, b) => b.revenue - a.revenue || a.name.localeCompare(b.name, 'tr'));
}

function dayKey(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function summarize(rows) {
  const acc = { revenue: 0, profit: 0, count: 0, discount: 0, cash: 0, card: 0, units: 0 };
  for (const row of rows) {
    const revenue = Number(row.gross) - Number(row.discount);
    const profit = Number(row.gross_profit) - Number(row.discount);
    if (row.payment_type === 'veresiye') {
      acc.count += 1;
      acc.units += Number(row.units);
      continue;
    }
    if (row.entry !== 'tahsilat') {
      acc.count += 1;
      acc.units += Number(row.units);
    }
    acc.revenue += revenue;
    acc.profit += profit;
    acc.discount += Number(row.discount);
    if (row.payment_type === 'nakit') acc.cash += revenue;
    else if (row.payment_type === 'kart') acc.card += revenue;
  }
  return acc;
}

function stats(ctx = {}) {
  const now = new Date();
  const today = startOfDay(now);
  const week = startOfWeek(now);
  const month = startOfMonth(now);
  const quarter = shiftMonths(today, -3);
  const year = shiftMonths(today, -12);
  const chartStart = shiftDays(today, -13);
  const yesterday = shiftDays(today, -1);
  const tomorrow = shiftDays(today, 1);
  const previousWeek = shiftDays(week, -7);
  const previousMonth = startOfMonth(shiftDays(month, -1));
  const previousQuarter = shiftMonths(today, -6);
  const previousYear = shiftMonths(today, -24);
  const fromDay = parseDay(ctx.url?.searchParams.get('from'));
  const toDay = parseDay(ctx.url?.searchParams.get('to'));
  let rangeStart = null;
  let rangeEnd = null;
  if (fromDay && toDay) {
    if (fromDay > toDay) throw httpError(400, 'Bitiş, başlangıçtan önce olamaz');
    rangeStart = fromDay;
    rangeEnd = shiftDays(toDay, 1);
    const length = Math.round((rangeEnd.getTime() - rangeStart.getTime()) / 86400000);
    if (length > 366) throw httpError(400, 'Aralık en fazla bir yıl olabilir');
  }
  let since = previousYear;
  if (rangeStart) {
    const length = Math.round((rangeEnd.getTime() - rangeStart.getTime()) / 86400000);
    const prevStart = shiftDays(rangeStart, -length);
    if (prevStart < since) since = prevStart;
  }
  const rows = db.prepare(`
    SELECT s.id, s.created_at, s.payment_type, s.discount, s.seller,
      COALESCE(SUM(${grossExpr()}), 0) AS gross,
      COALESCE(SUM(${profitExpr()}), 0) AS gross_profit,
      COALESCE(SUM(l.qty), 0) AS units
    FROM sales s
    LEFT JOIN sale_lines l ON l.sale_id = s.id
    WHERE s.cancelled_at IS NULL AND s.created_at >= ?
    GROUP BY s.id
  `).all(localStamp(since));
  const payments = db.prepare(`
    SELECT p.created_at, p.amount, p.payment_type, p.profit, s.seller
    FROM credit_payments p
    JOIN sales s ON s.id = p.sale_id
    WHERE s.cancelled_at IS NULL AND p.created_at >= ?
  `).all(localStamp(since)).map((row) => ({
    created_at: row.created_at,
    payment_type: row.payment_type,
    discount: 0,
    gross: Number(row.amount),
    gross_profit: Number(row.profit),
    units: 0,
    seller: row.seller || '',
    entry: 'tahsilat',
  }));
  const repairPayments = db.prepare(`
    SELECT p.created_at, p.amount, p.payment_type, p.profit, r.seller
    FROM credit_payments p
    JOIN repairs r ON r.id = p.repair_id
    WHERE r.status = 'teslim' AND p.created_at >= ?
  `).all(localStamp(since)).map((row) => ({
    created_at: row.created_at,
    payment_type: row.payment_type,
    discount: 0,
    gross: Number(row.amount),
    gross_profit: Number(row.profit),
    units: 0,
    seller: row.seller || '',
    entry: 'tahsilat',
    repair: true,
  }));
  const money = [...rows, ...payments, ...repairPayments];

  const stock = db.prepare(`
    SELECT
      COALESCE(SUM(CASE WHEN active = 1 THEN 1 ELSE 0 END), 0) AS product_count,
      COALESCE(SUM(CASE WHEN active = 1 AND stock > 0 THEN stock ELSE 0 END), 0) AS unit_count,
      COALESCE(SUM(CASE WHEN active = 1 THEN CASE WHEN stock > 0 THEN stock * cost_price ELSE 0 END + extra_cost ELSE 0 END), 0) AS cost_value,
      COALESCE(SUM(CASE WHEN active = 1 AND stock > 0 THEN stock * sale_price ELSE 0 END), 0) AS shelf_value,
      COALESCE(SUM(CASE WHEN active = 1 AND stock <= low_stock THEN 1 ELSE 0 END), 0) AS low_count
    FROM products
  `).get();

  const lowStock = db.prepare(`
    SELECT id, name, stock, low_stock
    FROM products
    WHERE active = 1 AND stock <= low_stock
    ORDER BY stock ASC, name ASC
    LIMIT 6
  `).all().map((row) => ({
    id: Number(row.id),
    name: row.name,
    stock: Number(row.stock),
    lowStock: Number(row.low_stock),
  }));

  const topSellers = db.prepare(`
    SELECT p.id, p.name,
      COALESCE(SUM(l.qty), 0) AS qty,
      COALESCE(SUM(${grossExpr()}), 0) AS revenue,
      COALESCE(SUM(${profitExpr()}), 0) AS profit,
      COALESCE(SUM(CASE WHEN s.payment_type = 'kart' THEN ${grossExpr()} ELSE 0 END), 0) AS card_revenue
    FROM sale_lines l
    JOIN sales s ON s.id = l.sale_id
    JOIN products p ON p.id = l.product_id
    WHERE s.cancelled_at IS NULL AND s.created_at >= ?
    GROUP BY p.id
    ORDER BY qty DESC, revenue DESC
    LIMIT 5
  `).all(localStamp(month)).map((row) => ({
    id: Number(row.id),
    name: row.name,
    qty: Number(row.qty),
    revenue: Number(row.revenue),
    profit: Number(row.profit) - posCutOf(row.card_revenue),
  }));

  const payoutRows = db.prepare('SELECT created_at, amount FROM payouts WHERE created_at >= ?').all(localStamp(since));
  const purchaseRows = db.prepare(`
    SELECT created_at, qty, unit_cost
    FROM stock_movements
    WHERE type = 'giris' AND created_at >= ?
  `).all(localStamp(since));
  const repairRows = db.prepare(`
    SELECT id, delivered_at AS created_at, fee, payment_type, seller, device,
      COALESCE((SELECT SUM(cost) FROM repair_parts WHERE repair_id = repairs.id AND restored = 0), 0) AS parts_cost
    FROM repairs
    WHERE status = 'teslim' AND fee > 0 AND delivered_at >= ?
  `).all(localStamp(since));
  const days = dayRows(money, payoutRows, repairRows, purchaseRows, chartStart, tomorrow).map((day) => ({
    date: day.date,
    revenue: day.revenue,
    profit: day.profit,
    count: day.count,
  }));
  const listReceipts = (start, end) => {
    const sales = db.prepare(`
      SELECT s.id, s.created_at, s.seller, s.customer, s.payment_type, s.discount,
        COALESCE(SUM(${grossExpr()}), 0) AS gross,
        COALESCE(SUM(${profitExpr()}), 0) AS gross_profit,
        COALESCE(GROUP_CONCAT(CASE WHEN l.qty > 1 THEN l.product_name || ' ×' || l.qty ELSE l.product_name END, ' · '), '') AS items
      FROM sales s
      LEFT JOIN sale_lines l ON l.sale_id = s.id
      WHERE s.cancelled_at IS NULL AND s.created_at >= ? AND s.created_at < ?
      GROUP BY s.id
    `).all(localStamp(start), localStamp(end)).map((row) => ({
      id: Number(row.id),
      createdAt: row.created_at,
      seller: row.seller || '',
      paymentType: row.payment_type === 'kart' ? 'kart' : row.payment_type === 'veresiye' ? 'veresiye' : 'nakit',
      customer: row.customer || '',
      total: Number(row.gross) - Number(row.discount),
      profit: profitAfterPos(Number(row.gross_profit) - Number(row.discount), Number(row.gross) - Number(row.discount), row.payment_type),
      items: row.items || '',
      kind: 'satis',
    }));
    const collected = db.prepare(`
      SELECT p.id, p.created_at, p.amount, p.payment_type, p.profit, s.id AS sale_id, s.seller, s.customer
      FROM credit_payments p
      JOIN sales s ON s.id = p.sale_id
      WHERE p.created_at >= ? AND p.created_at < ?
    `).all(localStamp(start), localStamp(end)).map((row) => ({
      id: Number(row.id),
      saleId: Number(row.sale_id),
      createdAt: row.created_at,
      seller: row.seller || '',
      customer: row.customer || '',
      paymentType: row.payment_type === 'kart' ? 'kart' : 'nakit',
      total: Number(row.amount),
      profit: profitAfterPos(Number(row.profit), Number(row.amount), row.payment_type),
      items: `Tahsilat · ${row.customer || 'Müşteri'}`,
      kind: 'tahsilat',
    }));
    const jobs = inSpan(repairRows, start, end).map((row) => ({
      id: Number(row.id),
      createdAt: row.created_at,
      seller: row.seller || '',
      paymentType: row.payment_type === 'kart' ? 'kart' : row.payment_type === 'veresiye' ? 'veresiye' : 'nakit',
      total: Number(row.fee),
      profit: profitAfterPos(Number(row.fee) - Number(row.parts_cost || 0), Number(row.fee), row.payment_type),
      items: `Tamir · ${row.device}`,
      kind: 'tamir',
    }));
    const repairPaid = db.prepare(`
      SELECT p.id, p.created_at, p.amount, p.payment_type, p.profit, r.id AS repair_id, r.seller, r.customer, r.device
      FROM credit_payments p
      JOIN repairs r ON r.id = p.repair_id
      WHERE p.created_at >= ? AND p.created_at < ?
    `).all(localStamp(start), localStamp(end)).map((row) => ({
      id: Number(row.id),
      repairId: Number(row.repair_id),
      createdAt: row.created_at,
      seller: row.seller || '',
      customer: row.customer || '',
      paymentType: row.payment_type === 'kart' ? 'kart' : 'nakit',
      total: Number(row.amount),
      profit: profitAfterPos(Number(row.profit), Number(row.amount), row.payment_type),
      items: `Tahsilat · ${row.device || row.customer || 'Tamir'}`,
      kind: 'tahsilat',
    }));
    return [...sales, ...jobs, ...collected, ...repairPaid].sort((a, b) => (a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : b.id - a.id));
  };
  const todayRows = inSpan(money, today, tomorrow);
  const weekRows = inSpan(money, week, tomorrow);
  const monthRows = inSpan(money, month, tomorrow);
  const quarterRows = inSpan(money, quarter, tomorrow);
  const yearRows = inSpan(money, year, tomorrow);
  const todayRepairs = inSpan(repairRows, today, tomorrow);
  const weekRepairs = inSpan(repairRows, week, tomorrow);
  const monthRepairs = inSpan(repairRows, month, tomorrow);
  const quarterRepairs = inSpan(repairRows, quarter, tomorrow);
  const yearRepairs = inSpan(repairRows, year, tomorrow);
  let range = null;
  if (rangeStart) {
    const length = Math.round((rangeEnd.getTime() - rangeStart.getTime()) / 86400000);
    const prevStart = shiftDays(rangeStart, -length);
    range = {
      from: dayKey(rangeStart),
      to: dayKey(shiftDays(rangeEnd, -1)),
      summary: summarizeSpan(money, payoutRows, repairRows, purchaseRows, rangeStart, rangeEnd),
      previous: summarizeSpan(money, payoutRows, repairRows, purchaseRows, prevStart, rangeStart),
      days: dayRows(money, payoutRows, repairRows, purchaseRows, rangeStart, rangeEnd),
      sellers: sellerRows(inSpan(money, rangeStart, rangeEnd), inSpan(repairRows, rangeStart, rangeEnd)),
      receipts: length === 1 ? listReceipts(rangeStart, rangeEnd) : [],
    };
  }
  return {
    posRate: posRate(),
    today: summarizeSpan(money, payoutRows, repairRows, purchaseRows, today, tomorrow),
    week: summarizeSpan(money, payoutRows, repairRows, purchaseRows, week, tomorrow),
    month: summarizeSpan(money, payoutRows, repairRows, purchaseRows, month, tomorrow),
    quarter: summarizeSpan(money, payoutRows, repairRows, purchaseRows, quarter, tomorrow),
    year: summarizeSpan(money, payoutRows, repairRows, purchaseRows, year, tomorrow),
    previous: {
      today: summarizeSpan(money, payoutRows, repairRows, purchaseRows, yesterday, today),
      week: summarizeSpan(money, payoutRows, repairRows, purchaseRows, previousWeek, week),
      month: summarizeSpan(money, payoutRows, repairRows, purchaseRows, previousMonth, month),
      quarter: summarizeSpan(money, payoutRows, repairRows, purchaseRows, previousQuarter, quarter),
      year: summarizeSpan(money, payoutRows, repairRows, purchaseRows, previousYear, year),
    },
    spanDays: {
      today: dayRows(money, payoutRows, repairRows, purchaseRows, today, tomorrow),
      week: dayRows(money, payoutRows, repairRows, purchaseRows, week, tomorrow),
      month: dayRows(money, payoutRows, repairRows, purchaseRows, month, tomorrow),
      quarter: dayRows(money, payoutRows, repairRows, purchaseRows, quarter, tomorrow),
      year: dayRows(money, payoutRows, repairRows, purchaseRows, year, tomorrow),
    },
    sellers: {
      today: sellerRows(todayRows, todayRepairs),
      week: sellerRows(weekRows, weekRepairs),
      month: sellerRows(monthRows, monthRepairs),
      quarter: sellerRows(quarterRows, quarterRepairs),
      year: sellerRows(yearRows, yearRepairs),
    },
    receipts: listReceipts(today, tomorrow),
    range,
    stock: {
      productCount: Number(stock.product_count),
      unitCount: Number(stock.unit_count),
      costValue: Number(stock.cost_value),
      shelfValue: Number(stock.shelf_value),
      lowCount: Number(stock.low_count),
    },
    lowStock,
    topSellers,
    days,
  };
}

function mapPayout(row) {
  return {
    id: Number(row.id),
    amount: Number(row.amount),
    note: row.note,
    repairId: row.repair_id ? Number(row.repair_id) : 0,
    createdAt: row.created_at,
  };
}

function listPayouts(ctx) {
  const offset = listOffset(ctx);
  const today = localStamp(startOfDay(new Date()));
  const rows = db.prepare('SELECT id, amount, note, repair_id, created_at FROM payouts ORDER BY id DESC LIMIT ? OFFSET ?').all(listPage + 1, offset);
  const todaySum = db.prepare('SELECT COALESCE(SUM(amount), 0) AS total FROM payouts WHERE created_at >= ?').get(today);
  return {
    payouts: rows.slice(0, listPage).map(mapPayout),
    today: Number(todaySum.total),
    more: rows.length > listPage,
  };
}

function listPurchases(ctx) {
  const offset = listOffset(ctx);
  const fromDay = parseDay(ctx.url.searchParams.get('from'));
  const toDay = parseDay(ctx.url.searchParams.get('to'));
  if ((ctx.url.searchParams.get('from') || ctx.url.searchParams.get('to')) && (!fromDay || !toDay)) {
    throw httpError(400, 'Tarih aralığı geçersiz');
  }
  if (fromDay && toDay && fromDay > toDay) throw httpError(400, 'Bitiş, başlangıçtan önce olamaz');
  const q = fold(ctx.url.searchParams.get('q') || '');
  const where = ["m.type = 'giris'"];
  const args = [];
  if (fromDay && toDay) {
    where.push('m.created_at >= ?');
    args.push(localStamp(fromDay));
    where.push('m.created_at < ?');
    args.push(localStamp(shiftDays(toDay, 1)));
  }
  const sql = `
    SELECT m.id, m.product_id, m.qty, m.unit_cost, m.note, m.created_at,
      p.name AS product_name, p.stock AS stock, p.cost_price, p.sale_price, p.active
    FROM stock_movements m
    JOIN products p ON p.id = m.product_id
    WHERE ${where.join(' AND ')}
    ORDER BY m.created_at DESC, m.id DESC
  `;
  let rows = db.prepare(sql).all(...args);
  if (q) {
    const words = q.split(/\s+/).filter(Boolean);
    rows = rows.filter((row) => {
      const hay = fold(`${row.product_name} ${row.note || ''}`);
      return words.every((word) => hay.includes(word));
    });
  }
  const totalSpend = rows.reduce((sum, row) => sum + Number(row.qty) * Number(row.unit_cost || 0), 0);
  const totalQty = rows.reduce((sum, row) => sum + Number(row.qty), 0);
  const page = rows.slice(offset, offset + listPage);
  return {
    purchases: page.map((row) => ({
      id: Number(row.id),
      productId: Number(row.product_id),
      productName: row.product_name,
      qty: Number(row.qty),
      unitCost: Number(row.unit_cost || 0),
      total: Number(row.qty) * Number(row.unit_cost || 0),
      stock: Number(row.stock),
      costPrice: Number(row.cost_price),
      salePrice: Number(row.sale_price),
      active: Number(row.active) === 1,
      note: row.note || '',
      createdAt: row.created_at,
    })),
    total: totalSpend,
    qty: totalQty,
    count: rows.length,
    more: rows.length > offset + listPage,
  };
}

function createPayout(ctx) {
  const note = cleanText(typeof ctx.body?.note === 'string' ? ctx.body.note : '', 'Açıklama', 160);
  const amount = cleanMoney(ctx.body?.amount, 'Tutar');
  if (amount <= 0) throw httpError(400, 'Tutarı yaz');
  const now = localStamp();
  const info = db.prepare('INSERT INTO payouts (amount, note, created_at) VALUES (?, ?, ?)').run(amount, note || 'Gider', now);
  record('gider', 'Gider eklendi', `${note || 'Gider'} · ${moneyLabel(amount)}`, '/gider', now);
  return { payout: mapPayout({ id: info.lastInsertRowid, amount, note: note || 'Gider', repair_id: null, created_at: now }) };
}

function deletePayout(id) {
  const row = db.prepare('SELECT amount, note, repair_id FROM payouts WHERE id = ?').get(id);
  if (!row) throw httpError(404, 'Gider yok');
  db.prepare('DELETE FROM payouts WHERE id = ?').run(id);
  record('gider', 'Gider silindi', `${row.note || 'Gider'} · ${moneyLabel(row.amount)}`, row.repair_id ? `/tamir/${row.repair_id}` : '/gider');
  return { ok: true };
}

function repairCosts(repairId) {
  return db.prepare(`
    SELECT id, amount, note, repair_id, created_at
    FROM payouts WHERE repair_id = ? ORDER BY id
  `).all(repairId).map(mapPayout);
}

function addRepairCost(repairId, body) {
  const repair = repairRow(repairId);
  if (repair.status === 'teslim' || repair.status === 'iptal') throw httpError(409, 'Bu tamire gider yazılmaz');
  const amount = cleanMoney(body.amount, 'Tutar');
  if (amount <= 0) throw httpError(400, 'Tutarı yaz');
  const note = cleanText(typeof body.note === 'string' ? body.note : '', 'Açıklama', 160);
  const label = note || `Dış tamir · ${repair.device}`;
  const now = localStamp();
  withTx(() => {
    db.prepare('INSERT INTO payouts (amount, note, repair_id, created_at) VALUES (?, ?, ?, ?)').run(amount, label, repairId, now);
    record('gider', 'Tamir gideri', `${label} · ${moneyLabel(amount)}`, `/tamir/${repairId}`, now);
  });
  return getRepair(repairId);
}

function removeRepairCost(repairId, costId) {
  const repair = repairRow(repairId);
  if (repair.status === 'teslim') throw httpError(409, 'Teslim edilen kayıtta gider silinmez');
  const row = db.prepare('SELECT id, amount, note FROM payouts WHERE id = ? AND repair_id = ?').get(costId, repairId);
  if (!row) throw httpError(404, 'Gider yok');
  withTx(() => {
    db.prepare('DELETE FROM payouts WHERE id = ?').run(costId);
    record('gider', 'Tamir gideri silindi', `${row.note || 'Gider'} · ${moneyLabel(row.amount)}`, `/tamir/${repairId}`);
  });
  return getRepair(repairId);
}

function vitrinSearch(ctx) {
  const q = fold(ctx.url.searchParams.get('q') || '').trim();
  if (!q) return { items: [] };
  const rows = db.prepare(`
    SELECT name, code, sale_price
    FROM products
    WHERE active = 1 AND stock > 0
  `).all();
  const items = [];
  for (const row of rows) {
    const name = String(row.name);
    const code = String(row.code || '');
    if (fold(name).includes(q) || fold(code).includes(q)) {
      items.push({ name, salePrice: Number(row.sale_price) });
    }
  }
  items.sort((a, b) => a.name.localeCompare(b.name, 'tr'));
  return { items: items.slice(0, 30) };
}

const pinFails = [];

function assertPinPace() {
  const now = Date.now();
  while (pinFails.length > 0 && now - pinFails[0] > 60_000) pinFails.shift();
  if (pinFails.length >= 5) throw httpError(429, 'Çok denendi. Bir dakika sonra tekrar dene.');
}

function vitrinLockOn() {
  return getSetting('vitrin_lock') === '1' && Boolean(getSetting('pin'));
}

function saveVitrinLock(ctx) {
  if (ctx.body.enabled !== true) {
    setSetting('vitrin_lock', '0');
    setSetting('pin', '');
    record('ayar', 'Ayar', 'Vitrin kilidi kapatıldı');
    return { pinSet: false, vitrinLock: false };
  }
  const pin = typeof ctx.body.pin === 'string' ? ctx.body.pin : '';
  if (!/^\d{4}$/.test(pin)) throw httpError(400, 'PIN dört haneli olmalı');
  setSetting('pin', hashPin(pin));
  setSetting('vitrin_lock', '1');
  record('ayar', 'Ayar', 'Vitrin kilidi açıldı');
  return { pinSet: true, vitrinLock: true };
}

function unlock(ctx) {
  if (!vitrinLockOn()) return { ok: true };
  assertPinPace();
  const pin = typeof ctx.body.pin === 'string' ? ctx.body.pin : '';
  if (!/^\d{4}$/.test(pin) || !checkPin(pin)) {
    pinFails.push(Date.now());
    throw httpError(401, 'PIN hatalı');
  }
  pinFails.length = 0;
  return { ok: true };
}

function readVersion() {
  try {
    return fs.readFileSync(versionPath, 'utf8').trim();
  } catch {
    return '';
  }
}

const pinnedUpdateRepo = 'cagatykrc/AYTEKSTOCK';

function readUpdateRepo() {
  try {
    const parsed = JSON.parse(fs.readFileSync(updatePath, 'utf8'));
    const repo = typeof parsed.repo === 'string' ? parsed.repo.trim() : '';
    return repo === pinnedUpdateRepo ? repo : '';
  } catch {
    return '';
  }
}

function updateInfo() {
  return { version: readVersion(), repo: readUpdateRepo() };
}

function saveUpdateRepo() {
  throw httpError(403, 'Güncelleme deposu buradan değiştirilemez');
}

const repairStatuses = new Set(['geldi', 'tamir', 'parca', 'hazir', 'teslim', 'iptal']);

function repairLabel(device, customer, extra = '') {
  return [device, customer, extra].filter(Boolean).join(' · ');
}

const repairStatusTitle = {
  geldi: 'Tamir bekliyor',
  tamir: 'Tamire geçti',
  parca: 'Parça bekleniyor',
  hazir: 'Tamir hazır',
  teslim: 'Teslim edildi',
  iptal: 'Tamir iptal',
};

function mapRepair(row) {
  const fee = Number(row.fee);
  const paymentType = row.payment_type || '';
  const paid = paymentType === 'veresiye' ? Number(row.paid ?? repairBalance(row.id)?.paid ?? 0) : 0;
  return {
    id: Number(row.id),
    customer: row.customer,
    phone: row.phone || '',
    device: row.device,
    partsLabel: row.part_label || '',
    brand: row.brand || '',
    fault: row.fault,
    note: row.note || '',
    fee,
    paymentType,
    paid,
    remaining: paymentType === 'veresiye' ? Math.max(0, fee - paid) : 0,
    status: row.status,
    seller: row.seller || '',
    receivedAt: row.received_at,
    readyAt: row.ready_at || '',
    deliveredAt: row.delivered_at || '',
  };
}

function repairRow(id) {
  const row = db.prepare('SELECT * FROM repairs WHERE id = ?').get(id);
  if (!row) throw httpError(404, 'Tamir kaydı bulunamadı');
  return row;
}

function cleanPhone(value) {
  const text = cleanText(value ?? '', 'Telefon', 32);
  if (!text) return '';
  if (/\p{L}/u.test(text)) throw httpError(400, 'Telefon geçersiz');
  const formatted = formatPhone(text);
  const digits = formatted.replace(/\D/g, '');
  if (digits.length < 6 || digits.length > 15 || formatted.length > 24) throw httpError(400, 'Telefon geçersiz');
  return formatted;
}

function cleanRepairPayment(value) {
  const payment = value ?? '';
  if (payment !== '' && payment !== 'nakit' && payment !== 'kart' && payment !== 'veresiye') throw httpError(400, 'Ödeme tipi geçersiz');
  return payment;
}

function assertRepairClose(payment, fee, customer) {
  if (fee > 0 && !payment) throw httpError(400, 'Teslim için ödemeyi seç');
  if (payment === 'veresiye' && fee < 1) throw httpError(400, 'Veresiye için ücret yaz');
  if (payment === 'veresiye' && !String(customer || '').trim()) throw httpError(400, 'Veresiye için müşteri adını yaz');
}

function listRepairs(ctx) {
  const durum = ctx.url.searchParams.get('durum') || 'acik';
  const allowed = new Set(['acik', 'hazir', 'teslim', 'iptal', 'tumu']);
  if (!allowed.has(durum)) throw httpError(400, 'Tamir süzgeci geçersiz');
  const q = fold(ctx.url.searchParams.get('q') || '').trim();
  const offset = listOffset(ctx);
  const where = [];
  if (durum === 'acik') where.push("status IN ('geldi', 'tamir', 'parca', 'hazir')");
  else if (durum !== 'tumu') where.push('status = ?');
  const args = durum !== 'acik' && durum !== 'tumu' ? [durum] : [];
  const repairSql = `
    SELECT repairs.*,
      COALESCE((SELECT SUM(amount) FROM credit_payments WHERE repair_id = repairs.id), 0) AS paid,
      (
        SELECT GROUP_CONCAT(CASE WHEN qty > 1 THEN product_name || ' ×' || qty ELSE product_name END, ' · ')
        FROM repair_parts
        WHERE repair_id = repairs.id AND restored = 0
      ) AS part_label
    FROM repairs
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY
      CASE status WHEN 'hazir' THEN 0 WHEN 'tamir' THEN 1 WHEN 'parca' THEN 2 WHEN 'geldi' THEN 3 ELSE 4 END,
      CASE WHEN status = 'teslim' THEN delivered_at ELSE received_at END DESC,
      id DESC
  `;
  let rows;
  let more;
  if (q) {
    const words = q.split(/\s+/).filter(Boolean);
    const matched = db.prepare(repairSql).all(...args).filter((row) => {
      const hay = fold(`${row.customer} ${row.phone} ${row.device} ${row.brand} ${row.fault} ${row.note} ${row.seller} ${row.part_label || ''}`);
      return words.every((word) => hay.includes(word));
    });
    more = matched.length > offset + listPage;
    rows = matched.slice(offset, offset + listPage);
  } else {
    const page = db.prepare(`${repairSql} LIMIT ? OFFSET ?`).all(...args, listPage + 1, offset);
    more = page.length > listPage;
    rows = page.slice(0, listPage);
  }
  const counts = { acik: 0, hazir: 0, teslim: 0, iptal: 0, tumu: 0 };
  for (const row of db.prepare('SELECT status FROM repairs').all()) {
    counts.tumu += 1;
    if (row.status === 'hazir' || row.status === 'teslim' || row.status === 'iptal') counts[row.status] += 1;
    if (row.status === 'geldi' || row.status === 'tamir' || row.status === 'parca' || row.status === 'hazir') counts.acik += 1;
  }
  return { repairs: rows.map(mapRepair), counts, more };
}

function createRepair(ctx) {
  const body = ctx.body || {};
  const customer = cleanName(body.customer ?? '', 'Müşteri', 80);
  const phone = cleanPhone(body.phone ?? '');
  const device = cleanName(body.device, 'Cihaz', 80, true);
  const brand = cleanName(body.brand ?? '', 'Marka', 60);
  const fault = cleanText(body.fault, 'Arıza', 400, true);
  const note = cleanText(body.note ?? '', 'Not', 400);
  const fee = cleanMoney(body.fee ?? 0, 'Ücret');
  const seller = cleanText(body.seller ?? '', 'Satıcı', 40);
  const done = body.done === true;
  let payment = '';
  if (done) {
    payment = cleanRepairPayment(body.paymentType);
    assertRepairClose(payment, fee, customer);
  }
  const now = localStamp();
  const id = withTx(() => {
    const created = db.prepare(`
      INSERT INTO repairs (customer, phone, device, brand, fault, note, fee, payment_type, status, seller, received_at, ready_at, delivered_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      customer,
      phone,
      device,
      brand,
      fault,
      note,
      fee,
      done ? payment : '',
      done ? 'teslim' : 'geldi',
      seller,
      now,
      done ? now : '',
      done ? now : '',
    );
    const detail = done && fee > 0 ? repairLabel(device, customer, moneyLabel(fee)) : repairLabel(device, customer);
    const title = done && payment === 'veresiye' ? 'Veresiye teslim' : done ? 'Teslim edildi' : 'Tamire alındı';
    record('tamir', title, detail, `/tamir/${created.lastInsertRowid}`, now);
    rememberCustomer(customer, phone, now);
    return Number(created.lastInsertRowid);
  });
  return { repair: mapRepair(repairRow(id)) };
}

function partsFor(repairId) {
  return db.prepare(`
    SELECT id, product_id, product_name, qty, cost, extra_taken, restored, created_at
    FROM repair_parts WHERE repair_id = ? ORDER BY id
  `).all(repairId).map((row) => ({
    id: Number(row.id),
    productId: Number(row.product_id),
    productName: row.product_name,
    qty: Number(row.qty),
    cost: Number(row.cost),
    restored: Number(row.restored) === 1,
    createdAt: row.created_at,
  }));
}

function restoreRepairParts(repairId, now) {
  const parts = db.prepare('SELECT * FROM repair_parts WHERE repair_id = ? AND restored = 0').all(repairId);
  const update = db.prepare('UPDATE products SET stock = stock + ?, extra_cost = extra_cost + ?, updated_at = ? WHERE id = ?');
  const move = db.prepare(`
    INSERT INTO stock_movements (product_id, type, qty, note, sale_id, created_at)
    VALUES (?, 'tamir', ?, ?, NULL, ?)
  `);
  for (const part of parts) {
    const product = db.prepare('SELECT id FROM products WHERE id = ?').get(part.product_id);
    if (product) {
      update.run(Number(part.qty), Number(part.extra_taken || 0), now, Number(part.product_id));
      move.run(Number(part.product_id), Number(part.qty), `Tamir #${repairId} geri`, now);
    }
    db.prepare('UPDATE repair_parts SET restored = 1 WHERE id = ?').run(part.id);
  }
}

function repairPayments(id) {
  return db.prepare(`
    SELECT id, amount, payment_type, note, created_at
    FROM credit_payments WHERE repair_id = ? ORDER BY id
  `).all(id).map((row) => ({
    id: Number(row.id),
    amount: Number(row.amount),
    paymentType: row.payment_type === 'kart' ? 'kart' : 'nakit',
    note: row.note || '',
    createdAt: row.created_at,
  }));
}

function getRepair(id) {
  const repair = mapRepair(repairRow(id));
  return {
    repair,
    parts: partsFor(id),
    costs: repairCosts(id),
    payments: repair.paymentType === 'veresiye' ? repairPayments(id) : [],
  };
}

function updateRepair(id, body) {
  const current = repairRow(id);
  if (current.status === 'teslim') {
    if (body.revert !== true) throw httpError(409, 'Teslim edilen tamir kilitli. Önce teslimi geri alın.');
    const taken = db.prepare('SELECT COALESCE(SUM(amount), 0) AS paid FROM credit_payments WHERE repair_id = ?').get(id);
    if (Number(taken.paid) > 0) throw httpError(409, 'Tahsilat var. Teslim geri alınamaz.');
    const now = localStamp();
    withTx(() => {
      db.prepare(`
        UPDATE repairs
        SET status = 'hazir', payment_type = '', delivered_at = '', ready_at = CASE WHEN ready_at = '' THEN ? ELSE ready_at END
        WHERE id = ?
      `).run(now, id);
      record('tamir', 'Teslim geri alındı', repairLabel(current.device, current.customer), `/tamir/${id}`, now);
    });
    return getRepair(id);
  }
  const customer = 'customer' in body ? cleanName(body.customer ?? '', 'Müşteri', 80) : current.customer;
  const phone = 'phone' in body ? cleanPhone(body.phone) : current.phone;
  const device = 'device' in body ? cleanName(body.device, 'Cihaz', 80, true) : current.device;
  const brand = 'brand' in body ? cleanName(body.brand ?? '', 'Marka', 60) : current.brand;
  const fault = 'fault' in body ? cleanText(body.fault, 'Arıza', 400, true) : current.fault;
  const note = 'note' in body ? cleanText(body.note ?? '', 'Not', 400) : current.note;
  const fee = 'fee' in body ? cleanMoney(body.fee, 'Ücret') : Number(current.fee);
  const seller = 'seller' in body ? cleanText(body.seller ?? '', 'Satıcı', 40) : current.seller;
  const status = 'status' in body ? body.status : current.status;
  if (!repairStatuses.has(status)) throw httpError(400, 'Tamir durumu geçersiz');
  let payment = 'paymentType' in body ? cleanRepairPayment(body.paymentType) : (current.payment_type || '');
  if (status !== 'teslim') payment = '';
  if (status === 'teslim') assertRepairClose(payment, fee, customer);
  const now = localStamp();
  let readyAt = current.ready_at || '';
  let deliveredAt = current.delivered_at || '';
  if (status === 'hazir' && !readyAt) readyAt = now;
  if (status !== 'hazir' && status !== 'teslim') readyAt = '';
  if (status === 'teslim' && !deliveredAt) deliveredAt = now;
  if (status !== 'teslim') deliveredAt = '';
  const changedStatus = status !== current.status;
  const changedFee = fee !== Number(current.fee);
  withTx(() => {
    db.prepare(`
      UPDATE repairs
      SET customer = ?, phone = ?, device = ?, brand = ?, fault = ?, note = ?, fee = ?, payment_type = ?, status = ?, seller = ?, ready_at = ?, delivered_at = ?
      WHERE id = ?
    `).run(customer, phone, device, brand, fault, note, fee, payment, status, seller, readyAt, deliveredAt, id);
    rememberCustomer(customer, phone, now);
    const ref = `/tamir/${id}`;
    if (changedStatus && status === 'iptal') restoreRepairParts(id, now);
    if (changedStatus) {
      const detail = status === 'teslim' && fee > 0 ? repairLabel(device, customer, moneyLabel(fee)) : repairLabel(device, customer);
      const title = status === 'teslim' && payment === 'veresiye' ? 'Veresiye teslim' : repairStatusTitle[status];
      record('tamir', title, detail, ref, now);
    } else if (changedFee) {
      record('tamir', 'Tamir ücreti', repairLabel(device, customer, moneyLabel(fee)), ref, now);
    }
  });
  return getRepair(id);
}

function deleteRepair(id) {
  const current = repairRow(id);
  if (current.status === 'teslim') throw httpError(409, 'Teslim edilen tamir silinmez. Önce teslimi geri alın.');
  withTx(() => {
    restoreRepairParts(id, localStamp());
    db.prepare('DELETE FROM repair_parts WHERE repair_id = ?').run(id);
    db.prepare('UPDATE payouts SET repair_id = NULL WHERE repair_id = ?').run(id);
    db.prepare('DELETE FROM repairs WHERE id = ?').run(id);
    record('tamir', 'Tamir kaydı silindi', repairLabel(current.device, current.customer));
  });
  return { ok: true };
}

function addRepairPart(repairId, body) {
  const qty = cleanQty(body.qty, 'Parça adedi');
  if (!Number.isInteger(body.productId) || body.productId < 1) throw httpError(400, 'Ürün geçersiz');
  const now = localStamp();
  withTx(() => {
    const repair = repairRow(repairId);
    if (repair.status === 'teslim' || repair.status === 'iptal') throw httpError(409, 'Bu tamire parça eklenmez');
    const product = rowById(body.productId);
    if (qty > Number(product.stock)) throw httpError(400, `Stok yetmiyor: ${product.name} (rafta ${product.stock})`);
    const taken = allocateExtra(Number(product.extra_cost || 0), qty, Number(product.stock));
    const cost = qty * Number(product.cost_price) + taken;
    db.prepare(`
      INSERT INTO repair_parts (repair_id, product_id, product_name, qty, cost, extra_taken, restored, created_at)
      VALUES (?, ?, ?, ?, ?, ?, 0, ?)
    `).run(repairId, product.id, product.name, qty, cost, taken, now);
    db.prepare('UPDATE products SET stock = stock - ?, extra_cost = extra_cost - ?, updated_at = ? WHERE id = ?')
      .run(qty, taken, now, product.id);
    db.prepare(`
      INSERT INTO stock_movements (product_id, type, qty, note, sale_id, created_at)
      VALUES (?, 'tamir', ?, ?, NULL, ?)
    `).run(product.id, -qty, `Tamir #${repairId}`, now);
    record('tamir', 'Parça kullanıldı', `${product.name} · ${qty} adet · ${repair.device}`, `/tamir/${repairId}`, now);
  });
  return getRepair(repairId);
}

function removeRepairPart(repairId, partId) {
  const now = localStamp();
  withTx(() => {
    const repair = repairRow(repairId);
    if (repair.status === 'teslim') throw httpError(409, 'Teslim edilen tamirden parça çıkmaz');
    const part = db.prepare('SELECT * FROM repair_parts WHERE id = ? AND repair_id = ?').get(partId, repairId);
    if (!part) throw httpError(404, 'Parça yok');
    if (Number(part.restored) !== 1) {
      const product = db.prepare('SELECT id FROM products WHERE id = ?').get(part.product_id);
      if (product) {
        db.prepare('UPDATE products SET stock = stock + ?, extra_cost = extra_cost + ?, updated_at = ? WHERE id = ?')
          .run(Number(part.qty), Number(part.extra_taken || 0), now, Number(part.product_id));
        db.prepare(`
          INSERT INTO stock_movements (product_id, type, qty, note, sale_id, created_at)
          VALUES (?, 'tamir', ?, ?, NULL, ?)
        `).run(Number(part.product_id), Number(part.qty), `Tamir #${repairId} geri`, now);
      }
    }
    db.prepare('DELETE FROM repair_parts WHERE id = ? AND repair_id = ?').run(partId, repairId);
    record('tamir', 'Parça geri alındı', `${part.product_name} · ${part.qty} adet`, `/tamir/${repairId}`, now);
  });
  return getRepair(repairId);
}

const routes = [
  ['GET', '/api/health', () => ({ ok: true })],
  ['GET', '/api/session', () => ({ pinSet: vitrinLockOn(), vitrinLock: vitrinLockOn() })],
  ['POST', '/api/settings/pin', saveVitrinLock],
  ['POST', '/api/vitrin/unlock', unlock],
  ['GET', '/api/vitrin', vitrinSearch],
  ['GET', '/api/settings/app', appSettings],
  ['POST', '/api/settings/app', saveAppSettings],
  ['POST', '/api/settings/open-folder', openFolder],
  ['POST', '/api/settings/open-guide', openGuide],
  ['POST', '/api/backup', () => {
    const made = backupDatabase();
    record('ayar', 'Yedek alındı', made.file);
    return made;
  }],
  ['GET', '/api/journal', listJournal],
  ['GET', '/api/drive', driveConfig],
  ['POST', '/api/drive', saveDriveConfig],
  ['POST', '/api/drive/client', saveDriveClient],
  ['POST', '/api/drive/connect', connectDrive],
  ['POST', '/api/drive/disconnect', disconnectDrive],
  ['POST', '/api/drive/backup', driveBackup],
  ['POST', '/api/drive/import', driveImport],
  ['GET', '/api/update', updateInfo],
  ['POST', '/api/update', saveUpdateRepo],
  ['GET', '/api/stats', stats],
  ['GET', '/api/categories', () => ({ categories: categories() })],
  ['GET', '/api/products', listProducts],
  ['POST', '/api/products', createProduct],
  ['GET', '/api/products/:id', (ctx) => productDetail(parseId(ctx.params.id))],
  ['PATCH', '/api/products/:id', (ctx) => updateProduct(parseId(ctx.params.id), ctx.body)],
  ['POST', '/api/products/:id/stock', (ctx) => adjustStock(parseId(ctx.params.id), ctx.body)],
  ['POST', '/api/products/:id/expenses', (ctx) => addExpense(parseId(ctx.params.id), ctx.body)],
  ['DELETE', '/api/products/:id/expenses/:expenseId', (ctx) => removeExpense(parseId(ctx.params.id), parseId(ctx.params.expenseId))],
  ['DELETE', '/api/products/:id', (ctx) => deleteProduct(parseId(ctx.params.id))],
  ['GET', '/api/sellers', listSellers],
  ['POST', '/api/sellers', saveSellers],
  ['GET', '/api/payouts', listPayouts],
  ['POST', '/api/payouts', createPayout],
  ['DELETE', '/api/payouts/:id', (ctx) => deletePayout(parseId(ctx.params.id))],
  ['GET', '/api/purchases', listPurchases],
  ['GET', '/api/repairs', listRepairs],
  ['POST', '/api/repairs', createRepair],
  ['POST', '/api/repairs/:id/parts', (ctx) => addRepairPart(parseId(ctx.params.id), ctx.body)],
  ['DELETE', '/api/repairs/:id/parts/:partId', (ctx) => removeRepairPart(parseId(ctx.params.id), parseId(ctx.params.partId))],
  ['POST', '/api/repairs/:id/costs', (ctx) => addRepairCost(parseId(ctx.params.id), ctx.body)],
  ['DELETE', '/api/repairs/:id/costs/:costId', (ctx) => removeRepairCost(parseId(ctx.params.id), parseId(ctx.params.costId))],
  ['GET', '/api/repairs/:id', (ctx) => getRepair(parseId(ctx.params.id))],
  ['POST', '/api/repairs/:id/pay', (ctx) => payRepair(parseId(ctx.params.id), ctx.body)],
  ['PATCH', '/api/repairs/:id', (ctx) => updateRepair(parseId(ctx.params.id), ctx.body)],
  ['DELETE', '/api/repairs/:id', (ctx) => deleteRepair(parseId(ctx.params.id))],
  ['GET', '/api/customers', listCustomers],
  ['GET', '/api/debts', listDebts],
  ['POST', '/api/debts/pay', (ctx) => payCustomer(ctx.body)],
  ['GET', '/api/sales', listSales],
  ['POST', '/api/sales', createSale],
  ['GET', '/api/sales/:id', (ctx) => getSale(parseId(ctx.params.id))],
  ['POST', '/api/sales/:id/pay', (ctx) => payCredit(parseId(ctx.params.id), ctx.body)],
  ['POST', '/api/sales/:id/cancel', (ctx) => cancelSale(parseId(ctx.params.id))],
];

function matchRoute(method, pathname) {
  for (const [routeMethod, routePath, handler] of routes) {
    if (routeMethod !== method) continue;
    const names = [];
    const pattern = routePath.replace(/:([A-Za-z]+)/g, (_, name) => {
      names.push(name);
      return '([^/]+)';
    });
    const matched = pathname.match(new RegExp(`^${pattern}$`));
    if (!matched) continue;
    const params = {};
    names.forEach((name, index) => {
      params[name] = matched[index + 1];
    });
    return { handler, params };
  }
  return null;
}

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function isInside(parent, file) {
  const relative = path.relative(parent, file);
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative));
}

function serveStatic(res, pathname) {
  const distRoot = path.resolve(distDir);
  const requested = path.resolve(distRoot, `.${pathname}`);
  let filePath = requested;
  if (!isInside(distRoot, filePath)) {
    res.writeHead(400, frameHeaders());
    res.end();
    return;
  }
  const missing = !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory();
  if (missing) {
    if (path.extname(pathname)) {
      res.writeHead(404, { ...frameHeaders(), 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Bulunamadı');
      return;
    }
    filePath = path.join(distRoot, 'index.html');
  }
  const ext = path.extname(filePath).toLowerCase();
  const headers = {
    ...frameHeaders(),
    'Content-Type': mime[ext] || 'application/octet-stream',
    'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=31536000, immutable',
  };
  if (ext === '.html') {
    const html = injectSession(fs.readFileSync(filePath, 'utf8'), sessionToken());
    const body = Buffer.from(html);
    headers['Content-Length'] = body.length;
    res.writeHead(200, headers);
    res.end(body);
    return;
  }
  res.writeHead(200, headers);
  fs.createReadStream(filePath).pipe(res);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', 'http://127.0.0.1');
    let pathname = decodeURIComponent(url.pathname);
    if (pathname.length > 1 && pathname.endsWith('/')) pathname = pathname.slice(0, -1);
    guardRequest(req, pathname);
    if (req.method === 'POST' && pathname === '/api/backup/import') {
      const bytes = await readRaw(req, 40_000_000);
      const restored = importDatabase(bytes);
      record('ayar', 'Yedek geri yüklendi', '');
      markShopChanged();
      send(res, 200, restored);
      return;
    }
    if (pathname.startsWith('/api')) {
      const match = matchRoute(req.method || 'GET', pathname);
      if (!match) {
        send(res, 404, { error: 'Bulunamadı' });
        return;
      }
      const body = req.method === 'GET' || req.method === 'HEAD' ? {} : await readBody(req);
      const result = await match.handler({ body, params: match.params, url });
      send(res, 200, result);
      return;
    }
    if (!fs.existsSync(path.join(distDir, 'index.html'))) {
      res.writeHead(200, { ...frameHeaders(), 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end('<p>Arayüz henüz derlenmedi.</p>');
      return;
    }
    serveStatic(res, pathname);
  } catch (error) {
    if (!error.status && /Stok eksi|Ek masraf eksi/.test(String(error.message || ''))) {
      error.status = 400;
      error.message = String(error.message).includes('Ek masraf') ? 'Ek masraf eksi olamaz' : 'Stok eksi olamaz';
    }
    const status = error.status || 500;
    if (status >= 500) console.error(error);
    if (!res.headersSent) {
      send(res, status, { error: status >= 500 ? 'Beklenmeyen bir hata oluştu' : error.message });
    }
  }
});

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`http://127.0.0.1:${port} kullanımda. Açık olan uygulamayı kapatıp yeniden dene.`);
  } else {
    console.error(error);
  }
  process.exit(1);
});

const shopBackupWaitMs = 60_000;
let shopBackupTimer = null;
let shopBackupEpoch = 0;
let shopBackupBusy = false;

function scheduleShopBackup() {
  if (shopBackupTimer) clearTimeout(shopBackupTimer);
  shopBackupTimer = setTimeout(() => {
    shopBackupTimer = null;
    void flushShopBackup();
  }, shopBackupWaitMs);
}

async function flushShopBackup() {
  if (shopBackupBusy || getSetting('backup_pending') !== '1') return;
  shopBackupBusy = true;
  const seen = shopBackupEpoch;
  try {
    const config = driveConfig();
    if (config.auto && config.ready) await driveBackup();
    else backupDatabase();
    if (shopBackupEpoch === seen) setSetting('backup_pending', '0');
    else scheduleShopBackup();
  } catch (error) {
    console.error(error);
    scheduleShopBackup();
  } finally {
    shopBackupBusy = false;
  }
}

onShopChanged(() => {
  shopBackupEpoch += 1;
  scheduleShopBackup();
});

try {
  fs.writeFileSync(path.join(dataDir, '.session'), sessionToken(), { encoding: 'utf8', mode: 0o600 });
} catch (error) {
  console.error(error);
}

server.listen(port, '127.0.0.1', () => {
  console.log(`Ay Teknoloji hazır: http://127.0.0.1:${port}`);
  if (getSetting('backup_pending') === '1') void flushShopBackup();
});
