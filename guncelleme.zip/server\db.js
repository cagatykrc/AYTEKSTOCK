import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const dataDir = path.join(root, 'data');
export const backupDir = path.join(dataDir, 'backups');
export const dbPath = process.env.AY_DB
  ? path.resolve(process.env.AY_DB)
  : path.join(dataDir, 'ayteknoloji.db');

fs.mkdirSync(path.dirname(dbPath), { recursive: true });
fs.mkdirSync(backupDir, { recursive: true });

export const db = new DatabaseSync(dbPath);
db.exec('PRAGMA foreign_keys = ON');
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA busy_timeout = 5000');

db.exec(`
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
) STRICT;

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT '',
  brand TEXT NOT NULL DEFAULT '',
  used INTEGER NOT NULL DEFAULT 0,
  warranty_until TEXT NOT NULL DEFAULT '',
  included TEXT NOT NULL DEFAULT '',
  cost_price INTEGER NOT NULL DEFAULT 0,
  sale_price INTEGER NOT NULL DEFAULT 0,
  stock INTEGER NOT NULL DEFAULT 0,
  low_stock INTEGER NOT NULL DEFAULT 1,
  note TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
) STRICT;

CREATE TABLE IF NOT EXISTS sales (
  id INTEGER PRIMARY KEY,
  created_at TEXT NOT NULL,
  payment_type TEXT NOT NULL CHECK (payment_type IN ('nakit', 'kart')),
  discount INTEGER NOT NULL DEFAULT 0,
  note TEXT NOT NULL DEFAULT '',
  seller TEXT NOT NULL DEFAULT '',
  cancelled_at TEXT
) STRICT;

CREATE TABLE IF NOT EXISTS sale_lines (
  id INTEGER PRIMARY KEY,
  sale_id INTEGER NOT NULL REFERENCES sales(id),
  product_id INTEGER NOT NULL,
  product_name TEXT NOT NULL,
  qty INTEGER NOT NULL,
  unit_sale_price INTEGER NOT NULL,
  unit_cost_price INTEGER NOT NULL
) STRICT;

CREATE TABLE IF NOT EXISTS stock_movements (
  id INTEGER PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(id),
  type TEXT NOT NULL CHECK (type IN ('giris', 'sayim', 'satis', 'iptal')),
  qty INTEGER NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  sale_id INTEGER REFERENCES sales(id),
  created_at TEXT NOT NULL
) STRICT;

CREATE INDEX IF NOT EXISTS idx_products_active ON products(active);
CREATE INDEX IF NOT EXISTS idx_movements_product ON stock_movements(product_id, id);
CREATE INDEX IF NOT EXISTS idx_sales_created ON sales(created_at);
CREATE INDEX IF NOT EXISTS idx_lines_sale ON sale_lines(sale_id);

CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY,
  product_id INTEGER NOT NULL REFERENCES products(id),
  amount INTEGER NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
) STRICT;

CREATE INDEX IF NOT EXISTS idx_expenses_product ON expenses(product_id, id);

CREATE TABLE IF NOT EXISTS payouts (
  id INTEGER PRIMARY KEY,
  amount INTEGER NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
) STRICT;

CREATE INDEX IF NOT EXISTS idx_payouts_created ON payouts(created_at, id);

CREATE TABLE IF NOT EXISTS journal (
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '',
  ref TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
) STRICT;

CREATE INDEX IF NOT EXISTS idx_journal_id ON journal(id);
CREATE INDEX IF NOT EXISTS idx_journal_created ON journal(created_at, id);

CREATE TABLE IF NOT EXISTS repairs (
  id INTEGER PRIMARY KEY,
  customer TEXT NOT NULL,
  phone TEXT NOT NULL DEFAULT '',
  device TEXT NOT NULL,
  brand TEXT NOT NULL DEFAULT '',
  fault TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  fee INTEGER NOT NULL DEFAULT 0,
  payment_type TEXT NOT NULL DEFAULT '' CHECK (payment_type IN ('', 'nakit', 'kart')),
  status TEXT NOT NULL CHECK (status IN ('geldi', 'tamir', 'parca', 'hazir', 'teslim', 'iptal')),
  seller TEXT NOT NULL DEFAULT '',
  received_at TEXT NOT NULL,
  ready_at TEXT NOT NULL DEFAULT '',
  delivered_at TEXT NOT NULL DEFAULT ''
) STRICT;

CREATE INDEX IF NOT EXISTS idx_repairs_status ON repairs(status, received_at, id);
`);

const saleColumns = db.prepare('PRAGMA table_info(sales)').all().map((column) => column.name);
if (saleColumns.includes('buyer') && !saleColumns.includes('seller')) {
  db.exec('ALTER TABLE sales RENAME COLUMN buyer TO seller');
} else if (!saleColumns.includes('seller')) {
  db.exec("ALTER TABLE sales ADD COLUMN seller TEXT NOT NULL DEFAULT ''");
}

const productColumns = db.prepare('PRAGMA table_info(products)').all().map((column) => column.name);
if (!productColumns.includes('extra_cost')) {
  db.exec('ALTER TABLE products ADD COLUMN extra_cost INTEGER NOT NULL DEFAULT 0');
}
if (!productColumns.includes('brand')) {
  db.exec("ALTER TABLE products ADD COLUMN brand TEXT NOT NULL DEFAULT ''");
}
if (!productColumns.includes('used')) {
  db.exec('ALTER TABLE products ADD COLUMN used INTEGER NOT NULL DEFAULT 0');
}
if (!productColumns.includes('warranty_until')) {
  db.exec("ALTER TABLE products ADD COLUMN warranty_until TEXT NOT NULL DEFAULT ''");
}
if (!productColumns.includes('included')) {
  db.exec("ALTER TABLE products ADD COLUMN included TEXT NOT NULL DEFAULT ''");
}

const saleLineSql = db.prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'sale_lines'").get();
if (saleLineSql && String(saleLineSql.sql).includes('REFERENCES products')) {
  db.exec('PRAGMA foreign_keys = OFF');
  db.exec(`
    CREATE TABLE sale_lines_new (
      id INTEGER PRIMARY KEY,
      sale_id INTEGER NOT NULL REFERENCES sales(id),
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      qty INTEGER NOT NULL,
      unit_sale_price INTEGER NOT NULL,
      unit_cost_price INTEGER NOT NULL
    ) STRICT;
    INSERT INTO sale_lines_new (id, sale_id, product_id, product_name, qty, unit_sale_price, unit_cost_price)
      SELECT id, sale_id, product_id, product_name, qty, unit_sale_price, unit_cost_price FROM sale_lines;
    DROP TABLE sale_lines;
    ALTER TABLE sale_lines_new RENAME TO sale_lines;
    CREATE INDEX IF NOT EXISTS idx_lines_sale ON sale_lines(sale_id);
  `);
  db.exec('PRAGMA foreign_keys = ON');
}

const liveLineColumns = db.prepare('PRAGMA table_info(sale_lines)').all().map((column) => column.name);
if (!liveLineColumns.includes('unit_extra_cost')) {
  db.exec('ALTER TABLE sale_lines ADD COLUMN unit_extra_cost INTEGER NOT NULL DEFAULT 0');
}

export function localStamp(date = new Date()) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

export function getSetting(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : null;
}

export function record(kind, title, detail = '', ref = '', at = localStamp()) {
  const text = String(detail || '').slice(0, 180);
  db.prepare('INSERT INTO journal (kind, title, detail, ref, created_at) VALUES (?, ?, ?, ?, ?)').run(kind, title, text, ref, at);
}

function lira(kurus) {
  return (Number(kurus) / 100).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function seedJournal() {
  const count = db.prepare('SELECT COUNT(*) AS n FROM journal').get();
  if (Number(count.n) > 0) return;
  const insert = db.prepare('INSERT INTO journal (kind, title, detail, ref, created_at) VALUES (?, ?, ?, ?, ?)');
  db.exec('BEGIN');
  try {
    for (const row of db.prepare('SELECT id, name, created_at FROM products').all()) {
      insert.run('urun', 'Ürün eklendi', row.name, `/stok/${row.id}`, row.created_at);
    }
    for (const row of db.prepare(`
      SELECT m.type, m.qty, m.note, m.sale_id, m.created_at, p.name, p.id AS product_id
      FROM stock_movements m
      JOIN products p ON p.id = m.product_id
    `).all()) {
      const qty = Math.abs(Number(row.qty));
      const name = row.name;
      const ref = row.sale_id ? `/satis/${row.sale_id}` : `/stok/${row.product_id}`;
      if (row.type === 'giris') insert.run('stok', 'Stok eklendi', `${name} · ${qty} adet`, `/stok/${row.product_id}`, row.created_at);
      else if (row.type === 'satis') insert.run('satis', 'Satıldı', `${name} · ${qty} adet`, ref, row.created_at);
      else if (row.type === 'iptal') insert.run('iptal', 'Satış iptal', `${name} · ${qty} adet`, ref, row.created_at);
      else insert.run('sayim', 'Sayım', `${name} · ${Number(row.qty) >= 0 ? '+' : '−'}${qty} adet`, `/stok/${row.product_id}`, row.created_at);
    }
    for (const row of db.prepare(`
      SELECT e.amount, e.note, e.created_at, p.name, p.id AS product_id
      FROM expenses e JOIN products p ON p.id = e.product_id
    `).all()) {
      insert.run('masraf', 'Ek masraf', `${row.name} · ${lira(row.amount)}${row.note ? ` · ${row.note}` : ''}`, `/stok/${row.product_id}`, row.created_at);
    }
    for (const row of db.prepare('SELECT amount, note, created_at FROM payouts').all()) {
      insert.run('gider', 'Gider eklendi', `${row.note || 'Gider'} · ${lira(row.amount)}`, '/gider', row.created_at);
    }
    db.exec('COMMIT');
  } catch (error) {
    try { db.exec('ROLLBACK'); } catch { /* işlem açılmadıysa */ }
    throw error;
  }
}

seedJournal();

export function setSetting(key, value) {
  db.prepare(`
    INSERT INTO settings (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(key, value);
}

export function hashPin(pin) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(pin, salt, 32).toString('hex');
  return `${salt}:${hash}`;
}

export function checkPin(pin) {
  const stored = getSetting('pin');
  if (!stored || !pin) return false;
  const [salt, hash] = stored.split(':');
  if (!salt || !hash || hash.length !== 64) return false;
  const actual = scryptSync(String(pin), salt, 32);
  const expected = Buffer.from(hash, 'hex');
  if (actual.length !== expected.length) return false;
  return timingSafeEqual(actual, expected);
}

export function importDatabase(bytes) {
  if (!Buffer.isBuffer(bytes) || bytes.length < 100 || bytes.subarray(0, 15).toString('utf8') !== 'SQLite format 3') {
    const error = new Error('Bu dosya bir yedek değil');
    error.status = 400;
    throw error;
  }
  const incomingPath = path.join(dataDir, 'incoming.db');
  fs.writeFileSync(incomingPath, bytes);
  const incoming = new DatabaseSync(incomingPath, { readOnly: true });
  let sellerColumn = "''";
  let hasExtra = false;
  let hasBrand = false;
  let hasUsed = false;
  let hasUnitExtra = false;
  let hasExpenses = false;
  let hasPayouts = false;
  let hasJournal = false;
  let hasRepairs = false;
  try {
    const names = new Set(incoming.prepare("SELECT name FROM sqlite_master WHERE type = 'table'").all().map((row) => row.name));
    for (const table of ['products', 'sales', 'sale_lines', 'stock_movements', 'settings']) {
      if (!names.has(table)) {
        const error = new Error('Bu dosya Ay Teknoloji yedeği değil');
        error.status = 400;
        throw error;
      }
    }
    const saleColumns = incoming.prepare('PRAGMA table_info(sales)').all().map((column) => column.name);
    if (saleColumns.includes('seller')) sellerColumn = 'seller';
    else if (saleColumns.includes('buyer')) sellerColumn = 'buyer';
    const productColumns = incoming.prepare('PRAGMA table_info(products)').all().map((column) => column.name);
    hasExtra = productColumns.includes('extra_cost');
    hasBrand = productColumns.includes('brand');
    hasUsed = productColumns.includes('used') && productColumns.includes('warranty_until') && productColumns.includes('included');
    hasUnitExtra = incoming.prepare('PRAGMA table_info(sale_lines)').all().some((column) => column.name === 'unit_extra_cost');
    hasExpenses = names.has('expenses');
    hasPayouts = names.has('payouts');
    if (names.has('journal')) {
      const journalColumns = incoming.prepare('PRAGMA table_info(journal)').all().map((column) => column.name);
      hasJournal = ['kind', 'title', 'detail', 'ref', 'created_at'].every((name) => journalColumns.includes(name));
    }
    if (names.has('repairs')) {
      const repairColumns = incoming.prepare('PRAGMA table_info(repairs)').all().map((column) => column.name);
      hasRepairs = ['customer', 'phone', 'device', 'brand', 'fault', 'note', 'fee', 'payment_type', 'status', 'seller', 'received_at', 'ready_at', 'delivered_at'].every((name) => repairColumns.includes(name));
    }
  } finally {
    incoming.close();
  }

  const escaped = incomingPath.replaceAll('\\', '/').replaceAll("'", "''");
  db.exec('PRAGMA foreign_keys = OFF');
  try {
    db.exec(`ATTACH DATABASE '${escaped}' AS incoming`);
    db.exec('BEGIN IMMEDIATE');
    db.exec('DELETE FROM repairs');
    db.exec('DELETE FROM journal');
    db.exec('DELETE FROM payouts');
    db.exec('DELETE FROM expenses');
    db.exec('DELETE FROM sale_lines');
    db.exec('DELETE FROM stock_movements');
    db.exec('DELETE FROM sales');
    db.exec('DELETE FROM products');
    db.exec('DELETE FROM settings');
    db.exec('INSERT INTO settings (key, value) SELECT key, value FROM incoming.settings');
    if (hasExtra) {
      db.exec(`
        INSERT INTO products (id, name, code, category, brand, used, warranty_until, included, cost_price, sale_price, stock, low_stock, note, active, created_at, updated_at, extra_cost)
        SELECT id, name, code, category, ${hasBrand ? 'brand' : "''"}, ${hasUsed ? 'used' : '0'}, ${hasUsed ? 'warranty_until' : "''"}, ${hasUsed ? 'included' : "''"}, cost_price, sale_price, stock, low_stock, note, active, created_at, updated_at, extra_cost FROM incoming.products
      `);
    } else {
      db.exec(`
        INSERT INTO products (id, name, code, category, brand, used, warranty_until, included, cost_price, sale_price, stock, low_stock, note, active, created_at, updated_at)
        SELECT id, name, code, category, ${hasBrand ? 'brand' : "''"}, ${hasUsed ? 'used' : '0'}, ${hasUsed ? 'warranty_until' : "''"}, ${hasUsed ? 'included' : "''"}, cost_price, sale_price, stock, low_stock, note, active, created_at, updated_at FROM incoming.products
      `);
    }
    db.exec(`
      INSERT INTO sales (id, created_at, payment_type, discount, note, seller, cancelled_at)
      SELECT id, created_at, payment_type, discount, note, ${sellerColumn}, cancelled_at FROM incoming.sales
    `);
    if (hasUnitExtra) {
      db.exec(`
        INSERT INTO sale_lines (id, sale_id, product_id, product_name, qty, unit_sale_price, unit_cost_price, unit_extra_cost)
        SELECT id, sale_id, product_id, product_name, qty, unit_sale_price, unit_cost_price, unit_extra_cost FROM incoming.sale_lines
      `);
    } else {
      db.exec(`
        INSERT INTO sale_lines (id, sale_id, product_id, product_name, qty, unit_sale_price, unit_cost_price)
        SELECT id, sale_id, product_id, product_name, qty, unit_sale_price, unit_cost_price FROM incoming.sale_lines
      `);
    }
    if (hasExpenses) {
      db.exec(`
        INSERT INTO expenses (id, product_id, amount, note, created_at)
        SELECT id, product_id, amount, note, created_at FROM incoming.expenses
      `);
    }
    if (hasPayouts) {
      db.exec(`
        INSERT INTO payouts (id, amount, note, created_at)
        SELECT id, amount, note, created_at FROM incoming.payouts
      `);
    }
    if (hasRepairs) {
      db.exec(`
        INSERT INTO repairs (id, customer, phone, device, brand, fault, note, fee, payment_type, status, seller, received_at, ready_at, delivered_at)
        SELECT id, customer, phone, device, brand, fault, note, fee, payment_type, status, seller, received_at, ready_at, delivered_at FROM incoming.repairs
      `);
    }
    if (hasJournal) {
      db.exec(`
        INSERT INTO journal (id, kind, title, detail, ref, created_at)
        SELECT id, kind, title, detail, ref, created_at FROM incoming.journal
      `);
    }
    db.exec(`
      INSERT INTO stock_movements (id, product_id, type, qty, note, sale_id, created_at)
      SELECT id, product_id, type, qty, note, sale_id, created_at FROM incoming.stock_movements
    `);
    db.exec('COMMIT');
  } catch (error) {
    try { db.exec('ROLLBACK'); } catch { /* işlem açılmadıysa */ }
    if (!error.status) error.status = 400;
    if (!error.message || error.message.startsWith('FOREIGN KEY') || error.message.includes('no such')) {
      error.message = 'Yedek bu sürüme uymuyor';
    }
    throw error;
  } finally {
    try { db.exec('DETACH DATABASE incoming'); } catch { /* bağlı değilse */ }
    db.exec('PRAGMA foreign_keys = ON');
    fs.rmSync(incomingPath, { force: true });
    fs.rmSync(`${incomingPath}-wal`, { force: true });
    fs.rmSync(`${incomingPath}-shm`, { force: true });
  }
  seedJournal();
  return { ok: true };
}

export function backupDatabase() {
  fs.mkdirSync(backupDir, { recursive: true });
  const filename = `ayteknoloji-${localStamp().replaceAll(':', '-').replaceAll(' ', '-')}.db`;
  const dest = path.join(backupDir, filename);
  db.exec('PRAGMA wal_checkpoint(FULL)');
  fs.writeFileSync(dest, db.serialize());
  return { file: filename, directory: 'data/backups' };
}
