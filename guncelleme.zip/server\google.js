import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { backupDatabase, dataDir, getSetting, importDatabase, markShopChanged, record, setSetting } from './db.js';

const clientPath = path.join(path.dirname(fileURLToPath(import.meta.url)), 'google-client.json');
const tokenPath = path.join(dataDir, 'google.json');
const scope = 'openid email https://www.googleapis.com/auth/drive.file';
const loginPort = 42813;
const folderName = 'Ay Teknoloji';
const fileName = 'Ay Teknoloji yedek.db';

let accessCache = { token: '', expires: 0 };
let connectBusy = false;

function fail(status, message) {
  const error = new Error(message);
  error.status = status;
  throw error;
}

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
}

function tighten(file) {
  try {
    if (fs.existsSync(file)) fs.chmodSync(file, 0o600);
  } catch {
    /* Windows bu izni her zaman uygulamaz */
  }
}

function readClient() {
  const parsed = readJson(clientPath);
  const source = parsed?.installed || parsed?.web || parsed;
  const clientId = typeof source?.client_id === 'string' ? source.client_id.trim() : '';
  const clientSecret = typeof source?.client_secret === 'string' ? source.client_secret.trim() : '';
  if (!clientId || !clientSecret) return null;
  return { clientId, clientSecret };
}

function readToken() {
  const parsed = readJson(tokenPath);
  if (!parsed || typeof parsed.refresh_token !== 'string' || !parsed.refresh_token) return null;
  return {
    refresh_token: parsed.refresh_token,
    email: typeof parsed.email === 'string' ? parsed.email : '',
    scope: typeof parsed.scope === 'string' ? parsed.scope : '',
  };
}

function tokenSeesDrive(token) {
  return Boolean(token) && token.scope.includes('drive.file');
}

export function driveConfig() {
  const token = readToken();
  return {
    configured: Boolean(readClient()),
    connected: Boolean(token),
    email: token?.email || '',
    auto: getSetting('drive_auto') !== '0',
    notify: getSetting('drive_notify') !== '0',
    needsReconnect: Boolean(token) && !tokenSeesDrive(token),
    ready: tokenSeesDrive(token),
  };
}

export function saveDriveConfig(ctx) {
  const nextAuto = ctx.body.auto === false ? '0' : '1';
  const nextNotify = ctx.body.notify === false ? '0' : '1';
  const notes = [];
  if ((getSetting('drive_auto') !== '0') !== (nextAuto !== '0')) {
    notes.push(nextAuto === '1' ? 'Değişince Drive’a gönder açıldı' : 'Değişince Drive’a gönder kapatıldı');
  }
  if ((getSetting('drive_notify') !== '0') !== (nextNotify !== '0')) {
    notes.push(nextNotify === '1' ? 'Yedek bildirimi açıldı' : 'Yedek bildirimi kapatıldı');
  }
  setSetting('drive_auto', nextAuto);
  setSetting('drive_notify', nextNotify);
  if (notes.length > 0) record('ayar', 'Ayar', notes.join(' · '));
  return driveConfig();
}

export function saveDriveClient(ctx) {
  const clientId = typeof ctx.body.clientId === 'string' ? ctx.body.clientId.trim() : '';
  const clientSecret = typeof ctx.body.clientSecret === 'string' ? ctx.body.clientSecret.trim() : '';
  if (!clientId.endsWith('.apps.googleusercontent.com')) {
    fail(400, 'İstemci kimliği Google’dan kopyalanmış olmalı');
  }
  if (clientSecret.length < 8) fail(400, 'Gizli anahtar eksik');
  fs.writeFileSync(clientPath, JSON.stringify({ client_id: clientId, client_secret: clientSecret }, null, 2), { mode: 0o600 });
  tighten(clientPath);
  record('ayar', 'Ayar', 'Google bağlantı bilgisi kaydedildi');
  return driveConfig();
}

export function disconnectDrive() {
  accessCache = { token: '', expires: 0 };
  fs.rmSync(tokenPath, { force: true });
  record('ayar', 'Ayar', 'Google Drive ayrıldı');
  return driveConfig();
}

function openBrowser(url) {
  const child = spawn('rundll32.exe', ['url.dll,FileProtocolHandler', url], {
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
  });
  child.unref();
}

function emailFromIdToken(idToken) {
  if (!idToken) return '';
  try {
    const payload = JSON.parse(Buffer.from(idToken.split('.')[1], 'base64url').toString('utf8'));
    return typeof payload.email === 'string' ? payload.email : '';
  } catch {
    return '';
  }
}

function failStatus(status, message) {
  const error = new Error(message);
  error.status = status;
  return error;
}

function beginLogin(state) {
  let settleCode;
  let failCode;
  const codePromise = new Promise((resolve, reject) => {
    settleCode = resolve;
    failCode = reject;
  });
  const port = loginPort;
  let finished = false;
  const server = http.createServer((req, res) => {
    try {
      const url = new URL(req.url || '/', `http://127.0.0.1:${port}/`);
      const hasResult = url.pathname === '/' && (url.searchParams.has('code') || url.searchParams.has('error'));
      if (!hasResult || finished) {
        res.writeHead(204);
        res.end();
        return;
      }
      finished = true;
      clearTimeout(timer);
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<!doctype html><meta charset="utf-8"><title>Ay Teknoloji</title><body style="margin:0;background:#111113;color:#f3f3f3;font-family:sans-serif;display:grid;place-items:center;height:100vh"><p>İzin alındı. Bu sekmeyi kapatıp Ay Teknoloji penceresine dön.</p></body>');
      server.close();
      if (url.searchParams.get('state') !== state) {
        failCode(failStatus(400, 'Google bağlantısı doğrulanamadı'));
        return;
      }
      if (url.searchParams.get('error')) {
        failCode(failStatus(400, 'Google bağlantısı iptal edildi'));
        return;
      }
      settleCode(url.searchParams.get('code') || '');
    } catch {
      if (!res.headersSent) {
        res.writeHead(500);
        res.end();
      }
    }
  });
  const timer = setTimeout(() => {
    server.close();
    failCode(failStatus(408, 'Google bağlantısı tamamlanmadı'));
  }, 180000);
  const portPromise = new Promise((resolve, reject) => {
    server.on('error', () => {
      clearTimeout(timer);
      reject(failStatus(500, 'Google dönüş adresi kullanımda. Bir kez daha dene.'));
    });
    server.listen(port, '127.0.0.1', () => resolve(port));
  });
  return { codePromise, portPromise };
}

export async function connectDrive() {
  const client = readClient();
  if (!client) fail(400, 'Önce Google istemci bilgisini kaydet');
  if (connectBusy) fail(409, 'Google bağlantısı zaten bekleniyor');
  connectBusy = true;
  try {
    const verifier = crypto.randomBytes(32).toString('base64url');
    const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
    const state = crypto.randomBytes(16).toString('base64url');
    const pending = beginLogin(state);
    const codeWait = pending.codePromise;
    codeWait.catch(() => undefined);
    const port = await pending.portPromise;
    const redirect = `http://127.0.0.1:${port}`;
    const auth = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    auth.searchParams.set('client_id', client.clientId);
    auth.searchParams.set('redirect_uri', redirect);
    auth.searchParams.set('response_type', 'code');
    auth.searchParams.set('scope', scope);
    auth.searchParams.set('code_challenge', challenge);
    auth.searchParams.set('code_challenge_method', 'S256');
    auth.searchParams.set('access_type', 'offline');
    auth.searchParams.set('prompt', 'consent');
    auth.searchParams.set('state', state);
    openBrowser(auth.toString());
    const code = await codeWait;
    const token = await postForm('https://oauth2.googleapis.com/token', {
      client_id: client.clientId,
      client_secret: client.clientSecret,
      code,
      code_verifier: verifier,
      grant_type: 'authorization_code',
      redirect_uri: redirect,
    });
    if (!token.refresh_token) fail(400, 'Google kalıcı izin vermedi. Tekrar bağlan.');
    fs.mkdirSync(dataDir, { recursive: true });
    fs.writeFileSync(tokenPath, JSON.stringify({
      refresh_token: token.refresh_token,
      email: emailFromIdToken(token.id_token),
      scope,
    }, null, 2));
    accessCache = {
      token: token.access_token || '',
      expires: Date.now() + Math.max(0, (token.expires_in || 0) - 60) * 1000,
    };
    setSetting('drive_auto', '1');
    record('ayar', 'Ayar', 'Google Drive bağlandı');
    return driveConfig();
  } finally {
    connectBusy = false;
  }
}

async function postForm(url, fields) {
  let response;
  try {
    response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(fields),
    });
  } catch {
    fail(503, 'İnternete ulaşılamadı');
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (data.error === 'invalid_grant') fail(401, 'Google bağlantısı sona erdi. Ayarlardan tekrar bağlan.');
    const detail = typeof data.error_description === 'string' ? data.error_description : data.error;
    fail(400, detail ? `Google oturumu alınamadı: ${detail}` : 'Google oturumu alınamadı');
  }
  return data;
}

async function accessToken() {
  if (accessCache.token && Date.now() < accessCache.expires) return accessCache.token;
  const client = readClient();
  const saved = readToken();
  if (!client || !saved) fail(400, 'Google hesabı bağlı değil');
  const token = await postForm('https://oauth2.googleapis.com/token', {
    client_id: client.clientId,
    client_secret: client.clientSecret,
    refresh_token: saved.refresh_token,
    grant_type: 'refresh_token',
  });
  accessCache = {
    token: token.access_token,
    expires: Date.now() + Math.max(0, (token.expires_in || 0) - 60) * 1000,
  };
  return accessCache.token;
}

async function driveFetch(url, options = {}) {
  const token = await accessToken();
  let response;
  try {
    response = await fetch(url, {
      ...options,
      headers: { Authorization: `Bearer ${token}`, ...options.headers },
    });
  } catch {
    fail(503, 'İnternete ulaşılamadı');
  }
  const bytes = Buffer.from(await response.arrayBuffer());
  if (!response.ok) {
    if (response.status === 401) {
      accessCache = { token: '', expires: 0 };
      fail(401, 'Google oturumu düştü. Ayarlardan tekrar bağlan.');
    }
    if (response.status === 403) fail(400, 'Yedeğin Drive’da görünmesi için Ayarlardan tekrar bağlan');
    fail(502, 'Google Drive yanıt vermedi');
  }
  return bytes;
}

function requireVisibleDrive() {
  const token = readToken();
  if (!token) fail(400, 'Google hesabı bağlı değil');
  if (!tokenSeesDrive(token)) fail(400, 'Yedeğin Drive’da görünmesi için Ayarlardan tekrar bağlan');
}

async function listDrive(query) {
  const bytes = await driveFetch(`https://www.googleapis.com/drive/v3/files?pageSize=100&fields=files(id,name,createdTime)&orderBy=${encodeURIComponent('createdTime desc')}&q=${encodeURIComponent(query)}`);
  const data = JSON.parse(bytes.toString('utf8'));
  return Array.isArray(data.files) ? data.files : [];
}

async function uploadNamed(folderId, name, bytes, replace) {
  if (replace) {
    const existing = await findDriveId(`name = '${name}' and '${folderId}' in parents and trashed = false`);
    if (existing) {
      await driveFetch(`https://www.googleapis.com/upload/drive/v3/files/${existing}?uploadType=media`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: bytes,
      });
      return;
    }
  }
  const boundary = `ay${crypto.randomBytes(8).toString('hex')}`;
  const head = Buffer.from(
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify({ name, parents: [folderId] })}\r\n--${boundary}\r\nContent-Type: application/octet-stream\r\n\r\n`,
    'utf8',
  );
  const tail = Buffer.from(`\r\n--${boundary}--`, 'utf8');
  await driveFetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
    method: 'POST',
    headers: { 'Content-Type': `multipart/related; boundary=${boundary}` },
    body: Buffer.concat([head, bytes, tail]),
  });
}

async function pruneDriveCopies(folderId) {
  const copies = await listDrive(`name contains 'ayteknoloji-' and '${folderId}' in parents and trashed = false`);
  for (const file of copies.slice(30)) {
    await driveFetch(`https://www.googleapis.com/drive/v3/files/${file.id}`, { method: 'DELETE' });
  }
}

async function findDriveId(query) {
  const bytes = await driveFetch(`https://www.googleapis.com/drive/v3/files?pageSize=1&fields=files(id)&q=${encodeURIComponent(query)}`);
  const data = JSON.parse(bytes.toString('utf8'));
  return data.files?.[0]?.id || '';
}

async function ensureFolder() {
  const existing = await findDriveId(`name = '${folderName}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`);
  if (existing) return existing;
  const bytes = await driveFetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify({ name: folderName, mimeType: 'application/vnd.google-apps.folder' }),
  });
  const created = JSON.parse(bytes.toString('utf8'));
  if (!created.id) fail(502, 'Drive klasörü açılamadı');
  return created.id;
}

export async function driveBackup() {
  requireVisibleDrive();
  const made = backupDatabase();
  const bytes = fs.readFileSync(path.join(dataDir, 'backups', made.file));
  const folderId = await ensureFolder();
  await uploadNamed(folderId, fileName, bytes, true);
  try {
    await uploadNamed(folderId, made.file, bytes, false);
    await pruneDriveCopies(folderId);
  } catch (error) {
    console.error(error);
  }
  return { file: fileName, folder: folderName };
}

tighten(clientPath);
tighten(tokenPath);

export async function driveImport() {
  requireVisibleDrive();
  const folderId = await findDriveId(`name = '${folderName}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`);
  const id = folderId
    ? await findDriveId(`name = '${fileName}' and '${folderId}' in parents and trashed = false`)
    : '';
  if (!id) fail(404, 'Drive’da Ay Teknoloji klasöründe yedek yok');
  const bytes = await driveFetch(`https://www.googleapis.com/drive/v3/files/${id}?alt=media`);
  importDatabase(bytes);
  record('ayar', 'Drive yedeği geri yüklendi', '');
  markShopChanged();
  return { ok: true, file: fileName };
}
